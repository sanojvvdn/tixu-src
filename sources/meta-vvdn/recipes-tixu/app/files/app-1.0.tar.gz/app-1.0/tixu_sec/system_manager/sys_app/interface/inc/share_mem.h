/* ===========================================================================
 * @file share_mem.h
 *
 * @path sys_app/interface/inc
 *
 * @desc This creates a communication interface using share memeory. 
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/

/**
* @page SHARED_MEM_DRV_HOW How to use shared memory API?
* 1. Call the API ShareMemInit(int key) (or pShareMemInit(int key))  with the key you added to initialize shared memory.\n
* 2. Now you can use any shared memory API functions as you want.\n
* @section SHARED_MEM_DRV_HOW_EX Example

#include <share_mem.h>
int main()
{ 
         int mid;
	mid = ShareMemInit(key);
	if(mid < 0){			
		return -1;
	}
	// more shared memory API
	return 0;
}

*/

/**
* @file share_mem.h
* @brief  API to shared memory
*/
#ifndef __SHARE_MEM_H__
#define __SHARE_MEM_H__

#define PROC_MEM_SIZE 4096*15
#define MAX_SHARE_PROC	8
#define SET_REQ_MEM_SECT_SIZE 6144
/**
* @ingroup UTILITY API
* @defgroup SHARED_MEM_DRV Shard memory API

* This is the communication interface of shared memory manager. 
 
*/
int ShareMemInit(int key); ///< Initial shared memory.
int pShareMemInit(int key); ///< Initial shared memory for private use .
int ShareMemRead(int offset,void *buf, int length); ///< Read shared memory.
int ShareMemWrite(int offset,void *buf, int length); ///< Write shared memory.

#endif

