/* ===========================================================================
* @file file_msg_drv.c
*
* @path $(IPNCPATH)\util
*
* @desc
* .
* Copyright (c) Appro Photoelectron Inc.  2008
*
* Use of this software is controlled by the terms and conditions found
* in the license agreement under which this software has been supplied
*
* =========================================================================== */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <share_mem.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sem_util.h>
#include <file_msg_drv.h>
#include <system_default.h>
#include <sys_env_type.h>
#include <syslog.h>
#include <sem_util.h>
#include <string.h>
#define  FLASH_ASCII_SAVE 

#ifdef DEBUG
#define DBG(fmt, args...)	printf("FileMsgDrv: Debug\n" fmt, ##args)
#else
#define DBG(fmt, args...)
#endif

#define ERR(fmt, args...)	printf("FileMsgDrv: Error\n" fmt, ##args)

#define SWAP(a, b)  {a ^= b; b ^= a; a ^= b;}
#define ONVIF_SCOPE "www.onvif.org"

static int qid,mid,gProcId, eCount = 0, gKey;
static void *pShareMem;
static SemHandl_t hndlDrvSem = NULL;
int x_cor[3], y_cor[3];

/*
 * @brief Function for converting string into integer.
 *
 * @param arg1 pointer to the string.
 * @param arg2 & arg3 pinter to integers.
 * return 0 on success.
 */

int StrToInt(char *str, int *x, int *y)
{
	int i, j;
	char x_cor[5], y_cor[5];

	char *p = strchr(str, 'X');
	for (i = 0; i < p - str; i++) {
		x_cor[i] = str[i];
	}
	x_cor[i] = '\0';
	i++;
	for (j = 0; i < strlen(str); i++, j++) {
		y_cor[j] = str[i];
	}
	y_cor[j] = '\0';
	*x = atoi(x_cor);
	*y = atoi(y_cor);
	return 0;
}

/*
 * @brief Function for spliting string.
 *
 * @param arg1 pointer to string.
 * return 0 on success.
 */
int StrSplit(char *str)
{
	int x = 0, i, j = 0, k;
	char buf[3][10];

	for (i = 0; i < strlen(str); i++) {
		if (str[i] == 'S') {
			for (k = 0; j < i; k++, j++) {
				buf[x][k] = str[j];
			}
			buf[x][k] = '\0';
			j++;
			x++;
		}
	}
	for (i = 0; i < 3; i++) {
		StrToInt(buf[i], &x_cor[i], &y_cor[i]);
	}
	return 0;
}

/**
* @brief Save message ID in file message driver

* Save a message ID to file message driver. This ID will be used to identify
*  who is communicating with file manager. This function is old method, please
*  use InitFileMsgDrv(int key,int iProcId) instead.
* @param iqid [I ] message ID
*/
void SaveQid(int iqid)
{
	qid = iqid;
}
/**
* @brief Send quit command to file manager.

* This command will make file manager stop running. After you called this, all
*  the other process can't get system information because file manager is down.
*/
void SendFileQuitCmd()
{
	FILE_MSG_BUF msgbuf;

	memset(&msgbuf, 0, sizeof(msgbuf));
	msgbuf.Des = MSG_TYPE_MSG1;
	msgbuf.src = 0;
	msgbuf.cmd = FILE_MSG_QUIT;
	msgsnd(qid, &msgbuf, sizeof(msgbuf)-sizeof(long), 0);/*send msg1*/
}

/**
* @brief Initialize file message driver.

* Initialize file message driver. Please see \ref FILE_MSG_DRV_HOW to learn more.
* @note This API must be used before use any other file message driver API.
* @param key [I ] Key number for message queue and share memory.
* @param iProcId [I ] Message ID(Which was define in \ref File_Msg_Def.h) to initialize file message driver.
* @retval 0 Success.
* @retval -1 Fail.
*/
int InitFileMsgDrv(int key,int iProcId)
{
	if(hndlDrvSem == NULL)
		hndlDrvSem = MakeSem();
	if(hndlDrvSem == NULL){
		return -1;
	}
	DBG("Semaphore Addr: %p\n", hndlDrvSem);
	if((qid = Msg_Init(key)) < 0){
		ERR("Message init fail\n");
		DestroySem(hndlDrvSem);
		return -1;
	}
	DBG("Qid: %d\n",qid);
	gKey = key;
	mid = pShareMemInit(key);
	if(mid < 0){
		ERR("Share memory id error\n");
		DestroySem(hndlDrvSem);
		return -1;
	}
	DBG("Share Memory id : %d\n", mid);
	pShareMem = shmat(mid,0,0);
	DBG("Share Memory Address:%p\n", pShareMem);
	gProcId = iProcId;
	return 0;
}
/**
* @brief Cleanup file message driver.

* This API shoud be called at the end of process.
*/
void CleanupFileMsgDrv()
{
	shmdt(pShareMem);
	DestroySem(hndlDrvSem);
}
/**
* @brief Get system information.

* Get system information from file manager. In order to make every change can
*  update quickly, this function return the pointer to share memory.
* @warning Do NOT modify where this pointer point to.
* @return Pointer to where system information was stored.
* @retval NULL Can't get system information.
*/
SysInfo *GetSysInfo()
{
	return (SysInfo *) pShareMem;
}

/**
 * @brief Save Configuration to flash
 * 
 * @retval 0 Success.
 * @retval -1 Fail
 */
int SaveToFlash()
{
	FILE_MSG_BUF msgbuf;
/* if error count is more than 3 initialize the message queue */
	if(eCount >= 3){
		eCount = 0;
		qid = Msg_Init(gKey);
	}
	memset(&msgbuf, 0, sizeof(msgbuf));
	msgbuf.Des = MSG_TYPE_MSG1;
	msgbuf.src = gProcId;
	msgbuf.cmd = FILE_MSG_SAVE;
	msgbuf.shmid = mid;
	msgbuf.shmidx = 0;
	SemWait(hndlDrvSem);
	msgsnd(qid, &msgbuf, sizeof(msgbuf)-sizeof(long), 0);/*send msg1*/
	msgrcv(qid, &msgbuf, sizeof(msgbuf)-sizeof(long), gProcId, 0);
	SemRelease(hndlDrvSem);

	if(msgbuf.length != sizeof(SysInfo)){
		ERR("Data write error\n");
		eCount++;
		return -1;
	}
	return 0;
}
/**
* @brief Reset system to default.
* @retval 0 Success.
* @retval -1 Fail
*/
int fResetSysInfo()
{
	FILE_MSG_BUF msgbuf;

	memset(&msgbuf, 0, sizeof(msgbuf));
	msgbuf.Des = MSG_TYPE_MSG1;
	msgbuf.src = gProcId;
	msgbuf.cmd = FILE_MSG_RESET;
	msgbuf.shmid = mid;
	SemWait(hndlDrvSem);
	msgsnd(qid, &msgbuf, sizeof(msgbuf)-sizeof(long), 0);/*send msg1*/
	msgrcv(qid, &msgbuf, sizeof(msgbuf)-sizeof(long), gProcId, 0);
	SemRelease(hndlDrvSem);
	if(msgbuf.length != sizeof(SysInfo)){
		ERR("FILE_MSG_RESET fail\n");
		return -1;
	}
	return 0;
}

/**
* @brief Set Wi-Fi mode in SysInfo.
* @retval 0 
*/
int fSetWifiMode(int mode)
{   
	SysInfo *pSysInfo = GetSysInfo();
	SemWait(hndlDrvSem);
	pSysInfo->wifi_info.wifi_mode = mode;
	SemRelease(hndlDrvSem);
	return 0;
}   

