/* ===========================================================================
 * @file sys_msg_drv.h
 *
 * @path sys_app/interface/inc
 *
 * @desc This is the communication interface to control system server. The interface
 * is implemented by Linux POSIX queue and share memory. So it will pause you
 * thread until command result return.
 * note: Call SysDrvInit() at initial, and call SysDrvExit() at the end of
 * process.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/
/**
* @page SYS_MSG_DRV_HOW How to use system message driver?

-# Add new message ID in \ref Sys_Msg_Def.h if needed.
-# Call the API SysDrvInit() with the ID you added to initialize file
	message driver.
-# Now you can use any system message driver functions as you want.
-# Call the API SysDrvExit() to cleanup system message driver.

* Your code may like following:

#include <sys_msg_drv.h>
int main()
{
	if(SysDrvInit(SYS_BOA_MSG) < 0){
		exit(1);
	}
	// Use system message driver API here.
	SysDrvExit();
	return 0;
}

* \b See \b also \ref FILE_MSG_DRV_HOW
*/

#ifndef _SYS_MSG_DRV_H_
#define _SYS_MSG_DRV_H_
#include <Msg_Def.h>

void SetSysProcId(int iProcId);
void SaveSysMsgId(int qid);
/* This function should be called at process initial !!! */
int SysDrvInit(int proc_id_set, int proc_id_get, int set_blk_en);
//int SysDrvInit(int proc_id_set);
int SysDrvExit();
/* API */
/*	Set Command	*/
void SendSysQuitCmd();
int Get_request_execute(void *data, unsigned int len);
int Set_request_execute(unsigned int field,void *data, unsigned int len);


/*********************/
#endif /* _SYS_MSG_DRV_H_ */

