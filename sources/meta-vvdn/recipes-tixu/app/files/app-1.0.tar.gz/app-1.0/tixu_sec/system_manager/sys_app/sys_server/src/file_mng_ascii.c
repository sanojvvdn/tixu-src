/* ===========================================================================
 * @file file_mng_ascii.c
 *
 * @path $SystemServer/src/
 *
 * @desc This file magnger libconfig interface.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <libconfig.h>
#include <file_mng.h>
#include <file_msg_drv.h>
#include <sys_env_type.h>
#include <file_mng_ascii.h>
#include <name_property.h>

const unsigned long table[256] = {
		0x00000000L, 0x77073096L, 0xee0e612cL, 0x990951baL, 0x076dc419L,
		0x706af48fL, 0xe963a535L, 0x9e6495a3L, 0x0edb8832L, 0x79dcb8a4L,
		0xe0d5e91eL, 0x97d2d988L, 0x09b64c2bL, 0x7eb17cbdL, 0xe7b82d07L,
		0x90bf1d91L, 0x1db71064L, 0x6ab020f2L, 0xf3b97148L, 0x84be41deL,
		0x1adad47dL, 0x6ddde4ebL, 0xf4d4b551L, 0x83d385c7L, 0x136c9856L,
		0x646ba8c0L, 0xfd62f97aL, 0x8a65c9ecL, 0x14015c4fL, 0x63066cd9L,
		0xfa0f3d63L, 0x8d080df5L, 0x3b6e20c8L, 0x4c69105eL, 0xd56041e4L,
		0xa2677172L, 0x3c03e4d1L, 0x4b04d447L, 0xd20d85fdL, 0xa50ab56bL,
		0x35b5a8faL, 0x42b2986cL, 0xdbbbc9d6L, 0xacbcf940L, 0x32d86ce3L,
		0x45df5c75L, 0xdcd60dcfL, 0xabd13d59L, 0x26d930acL, 0x51de003aL,
		0xc8d75180L, 0xbfd06116L, 0x21b4f4b5L, 0x56b3c423L, 0xcfba9599L,
		0xb8bda50fL, 0x2802b89eL, 0x5f058808L, 0xc60cd9b2L, 0xb10be924L,
		0x2f6f7c87L, 0x58684c11L, 0xc1611dabL, 0xb6662d3dL, 0x76dc4190L,
		0x01db7106L, 0x98d220bcL, 0xefd5102aL, 0x71b18589L, 0x06b6b51fL,
		0x9fbfe4a5L, 0xe8b8d433L, 0x7807c9a2L, 0x0f00f934L, 0x9609a88eL,
		0xe10e9818L, 0x7f6a0dbbL, 0x086d3d2dL, 0x91646c97L, 0xe6635c01L,
		0x6b6b51f4L, 0x1c6c6162L, 0x856530d8L, 0xf262004eL, 0x6c0695edL,
		0x1b01a57bL, 0x8208f4c1L, 0xf50fc457L, 0x65b0d9c6L, 0x12b7e950L,
		0x8bbeb8eaL, 0xfcb9887cL, 0x62dd1ddfL, 0x15da2d49L, 0x8cd37cf3L,
		0xfbd44c65L, 0x4db26158L, 0x3ab551ceL, 0xa3bc0074L, 0xd4bb30e2L,
		0x4adfa541L, 0x3dd895d7L, 0xa4d1c46dL, 0xd3d6f4fbL, 0x4369e96aL,
		0x346ed9fcL, 0xad678846L, 0xda60b8d0L, 0x44042d73L, 0x33031de5L,
		0xaa0a4c5fL, 0xdd0d7cc9L, 0x5005713cL, 0x270241aaL, 0xbe0b1010L,
		0xc90c2086L, 0x5768b525L, 0x206f85b3L, 0xb966d409L, 0xce61e49fL,
		0x5edef90eL, 0x29d9c998L, 0xb0d09822L, 0xc7d7a8b4L, 0x59b33d17L,
		0x2eb40d81L, 0xb7bd5c3bL, 0xc0ba6cadL, 0xedb88320L, 0x9abfb3b6L,
		0x03b6e20cL, 0x74b1d29aL, 0xead54739L, 0x9dd277afL, 0x04db2615L,
		0x73dc1683L, 0xe3630b12L, 0x94643b84L, 0x0d6d6a3eL, 0x7a6a5aa8L,
		0xe40ecf0bL, 0x9309ff9dL, 0x0a00ae27L, 0x7d079eb1L, 0xf00f9344L,
		0x8708a3d2L, 0x1e01f268L, 0x6906c2feL, 0xf762575dL, 0x806567cbL,
		0x196c3671L, 0x6e6b06e7L, 0xfed41b76L, 0x89d32be0L, 0x10da7a5aL,
		0x67dd4accL, 0xf9b9df6fL, 0x8ebeeff9L, 0x17b7be43L, 0x60b08ed5L,
		0xd6d6a3e8L, 0xa1d1937eL, 0x38d8c2c4L, 0x4fdff252L, 0xd1bb67f1L,
		0xa6bc5767L, 0x3fb506ddL, 0x48b2364bL, 0xd80d2bdaL, 0xaf0a1b4cL,
		0x36034af6L, 0x41047a60L, 0xdf60efc3L, 0xa867df55L, 0x316e8eefL,
		0x4669be79L, 0xcb61b38cL, 0xbc66831aL, 0x256fd2a0L, 0x5268e236L,
		0xcc0c7795L, 0xbb0b4703L, 0x220216b9L, 0x5505262fL, 0xc5ba3bbeL,
		0xb2bd0b28L, 0x2bb45a92L, 0x5cb36a04L, 0xc2d7ffa7L, 0xb5d0cf31L,
		0x2cd99e8bL, 0x5bdeae1dL, 0x9b64c2b0L, 0xec63f226L, 0x756aa39cL,
		0x026d930aL, 0x9c0906a9L, 0xeb0e363fL, 0x72076785L, 0x05005713L,
		0x95bf4a82L, 0xe2b87a14L, 0x7bb12baeL, 0x0cb61b38L, 0x92d28e9bL,
		0xe5d5be0dL, 0x7cdcefb7L, 0x0bdbdf21L, 0x86d3d2d4L, 0xf1d4e242L,
		0x68ddb3f8L, 0x1fda836eL, 0x81be16cdL, 0xf6b9265bL, 0x6fb077e1L,
		0x18b74777L, 0x88085ae6L, 0xff0f6a70L, 0x66063bcaL, 0x11010b5cL,
		0x8f659effL, 0xf862ae69L, 0x616bffd3L, 0x166ccf45L, 0xa00ae278L,
		0xd70dd2eeL, 0x4e048354L, 0x3903b3c2L, 0xa7672661L, 0xd06016f7L,
		0x4969474dL, 0x3e6e77dbL, 0xaed16a4aL, 0xd9d65adcL, 0x40df0b66L,
		0x37d83bf0L, 0xa9bcae53L, 0xdebb9ec5L, 0x47b2cf7fL, 0x30b5ffe9L,
		0xbdbdf21cL, 0xcabac28aL, 0x53b39330L, 0x24b4a3a6L, 0xbad03605L,
		0xcdd70693L, 0x54de5729L, 0x23d967bfL, 0xb3667a2eL, 0xc4614ab8L,
		0x5d681b02L, 0x2a6f2b94L, 0xb40bbe37L, 0xc30c8ea1L, 0x5a05df1bL,
		0x2d02ef8dL
};

#define DO1(buf)  crc = table[((int)crc ^ (*buf++)) & 0xff] ^ (crc >> 8);
#define DO2(buf)  DO1(buf); DO1(buf);
#define DO4(buf)  DO2(buf); DO2(buf);
#define DO8(buf)  DO4(buf); DO4(buf);

/*
 *  Fn     -  crc32_no_comp
 *  Brief  -  Compute crc for an input buffer
 *  Param  -  Input Buffer,Length,(crc=0)
 *  Return -  Computed CRC
 */
unsigned long crc32_no_comp(unsigned long crc, const unsigned char *buf, unsigned int len)
{
	while (len >= 8) {
		DO8(buf);
		len -= 8;
	}
	if (len)
	do {
		DO1(buf);
	} while (--len);

	return crc;
}

/*
 *  Fn     - calc_crc_header
 *  Brief  - calculate crc for the given file stream
 *  Param  - filestream/File pointer
 *  Return - computed crc
 */
unsigned long calc_crc_header(FILE *fp)
{
		unsigned long crc = 0;
		int start_count, end_count, size = 0;
		void *config_buffer;

		fseek(fp, 0L, SEEK_END);
		end_count = ftell(fp);
		fseek(fp, 4 * sizeof(long), SEEK_SET);
		start_count = ftell(fp);
		size = end_count - start_count;
		if (size != 0) {
				config_buffer = malloc(size);
				fread(config_buffer, 1, size, fp);
				crc = crc32_no_comp(0, config_buffer, size);
				free(config_buffer);
		}

		return crc;
}

/*
 *  Fn     -  validate_NameValue_file
 *  Brief  -  Validate the header of the configuration file
 *  Param  -  file pointer
 *  Return -  0 on Success,-1 error value on failure
 */
int validate_NameValue_file(FILE *fp)
{
	unsigned long MagicNum, read_crc, calc_crc, VerNum, ModelNum;
	int ret = 0;
	if (fread(&MagicNum, 1, sizeof(MagicNum), fp) != sizeof(MagicNum)) {
		ERROR_ASCII("Magic Number Read Failed\n");
		ret = -1;
	} else {
		if (MagicNum == MAGIC_NUM) {
			if (fread(&VerNum, 1, sizeof(VerNum), fp) != sizeof(VerNum)) {
				ERROR_ASCII("Version Number Read Failed\n");
				ret = -1;
			} else {
				if (VerNum == VERSION_NUM) {
					if (fread (&ModelNum, 1, sizeof(ModelNum), fp) != sizeof(ModelNum)) {
						ERROR_ASCII("Version Number Read Failed\n");
						ret = -1;
					} else {
						if (ModelNum == MODEL_NUM) {
        						if (fread (&read_crc, 1, sizeof(read_crc), fp) != sizeof(read_crc)) {
								ERROR_ASCII("CRC Read Failed\n");
								ret = -1;
							} else {
						        	calc_crc = calc_crc_header(fp);
								if (read_crc == calc_crc) {
									ret = 0;
						                } else {
							        	ERROR_ASCII("CRC Mismatch\n");
									ret = -5;
								}
							}
						} else {
					        	ERROR_ASCII("Model Number Mismatch\n");
							ret = -4;
						}
					}
				} else {
					ERROR_ASCII("Version Number Mismatch\n");
					ret = -3;
				}
			}
		} else {
			ERROR_ASCII("Magic Number Mismatch\n");
			ret = -2;
		}
	}

	return ret;
}

/*
 *  Fn     -  read_NameValue_cfg
 *  Brief  -  Read the name value configurations fron valid namevalue configuration file
 *  Param  -  config_t *cfg structure
 *  Return -  0 on Success,-1 on failure
 */
int read_NameValue_cfg(config_t *cfg)
{
	FILE *fp;
	static const char *namevalue_file = NAMEVALUE_CFG_FILE_L;
	static const char *namevalue_file_backup = NAMEVALUE_CFG_BACKUP_L;
	int ret = 0;
	char cmd[64];
	struct stat buf;
	if(stat(NAMEVALUE_CFG_FOLDER_F, &buf) == 0) {
		sprintf(cmd, "mkdir -p %s \n", NAMEVALUE_CFG_FOLDER_L);
		system(cmd);
		sprintf(cmd, "cp -f %s %s \n", NAMEVALUE_CFG_FILE_F, NAMEVALUE_CFG_FILE_L);
		system(cmd);
		sprintf(cmd, "cp -fr %s %s \n", NAMEVALUE_CFG_BACKUP_F, NAMEVALUE_CFG_BACKUP_L);
	} else {
		sprintf(cmd, "mkdir -p %s %s \n", NAMEVALUE_CFG_FOLDER_F, NAMEVALUE_CFG_FOLDER_L);
	}
	system(cmd);
	system("sync");
	if ((fp = fopen(namevalue_file, "r")) == NULL) {
		ERROR_ASCII("Can't open config file for reading\n");
		ret = -1;
	} else {
		if (validate_NameValue_file(fp) != 0) {
			fclose(fp);
			DBG_ASCII ("Configuration file is not Valid, Checking Backup file\n");
			ret = -1;
		} else {
			sprintf(cmd, "cp %s %s \n", namevalue_file, namevalue_file_backup);
			system(cmd);
			ret = 0;
		}
	}
	/* Reading Configuration file Failed so reading the backup file */
	if (ret != 0) {
		if ((fp = fopen(namevalue_file_backup, "r")) == NULL) {
			ERROR_ASCII("Can't open Backup config file for reading\n");
			ret = -1;
		} else {
			if (validate_NameValue_file(fp) != 0) {
				fclose(fp);
				DBG_ASCII("Backup config file is not valid\n");
				ret = -1;
			} else {
				sprintf(cmd, "cp %s %s \n",namevalue_file_backup, namevalue_file);
				system(cmd);
				ret = 0;
			}
		}
	}
	if (ret == 0) {
		fseek(fp, 4 * sizeof(long), SEEK_SET);
		if (!config_read(cfg, fp)) {
			ERROR_ASCII("Config file reading failed\n");
			ret = -1;
		}
		fclose(fp);
	}
	return ret;
}

/*
 *  Fn     -  write_NameValue_cfg
 *  Brief  -  Write the name value config structure into config file with proper header
 *  Param  -  config_t *cfg - namevalue configuration structure
 *  Return -  0 on Success,-1 on failure
 */
int write_NameValue_cfg(config_t *cfg)
{
	FILE *fp;
	int ret = 0;
	char cmd[64];
	unsigned long MagicNum = MAGIC_NUM;
	unsigned long crc = 0;
	unsigned long VerNum = VERSION_NUM;
	unsigned long ModelNum = MODEL_NUM;
	static const char *namevalue_file = NAMEVALUE_CFG_FILE_L;
	static const char *namevalue_file_backup = NAMEVALUE_CFG_BACKUP_L;
	struct stat buf;
	/* Check the config folder exist */
	if(stat(NAMEVALUE_CFG_FOLDER_L, &buf) != 0) {
		sprintf(cmd, "mkdir -p %s \n", NAMEVALUE_CFG_FOLDER_L);
		system(cmd);
	}
	/* Create Name value vile and add the header with crc,magic and version details */
	if ((fp = fopen(namevalue_file, "w+")) == NULL) {
		ERROR_ASCII("Can't create system file\n");
		ret = -1;
	} else {
		if (fseek(fp, 4 * sizeof(long), SEEK_SET) != 0) {
			ERROR_ASCII("Unable to seek config file \n");
			ret = -1;
		} else {
			config_write(cfg, fp);
			crc = calc_crc_header(fp);
			if (crc != 0) {
				fseek(fp, 0L, SEEK_SET);
				if (fwrite(&MagicNum, 1, sizeof(MagicNum), fp) != sizeof(MagicNum)) {
					ERROR_ASCII("Writing Magic Number failed\n");
					ret = -1;
				} else {
					if (fwrite (&VerNum, 1, sizeof(VerNum), fp) != sizeof(VerNum)) {
						ERROR_ASCII("Writing Version Number fail\n");
						ret = -1;
					} else {
						if (fwrite (&ModelNum, 1, sizeof(ModelNum), fp) != sizeof(ModelNum)) {
							ERROR_ASCII("Writing Model Number fail\n");
							ret = -1;
						} else {
							if (fwrite(&crc, 1, sizeof(crc), fp) != sizeof(crc)) {
								ERROR_ASCII("Writing CRC fail\n");
								ret = -1;
							}
							ret = 0;
						}
					}
				}
			} else {
				ERROR_ASCII("CRC Calculation failed\n");
			}
			DBG_ASCII("CRC=%lx\n", crc);
		}
		fclose(fp);
	}

	/*  Copy the namevalue file to backupfile on success. Else copy the backup file to main file */
	if (ret != 0)
	sprintf(cmd, "cp %s %s \n", namevalue_file_backup, namevalue_file);
	else
	sprintf(cmd, "cp %s %s \n", namevalue_file, namevalue_file_backup);
	system(cmd);

	return ret;
}

/*
 *  Fn     -  read_NameValue_file
 *  Brief  -  Read the name value configuration file and update System Configurations
 *  Param  -  System Configuration Buffer (SysInfo)
 *  Return -  0 on Success
 */
int read_NameValue_file(void *Buffer)
{
	config_t cfg;
	config_setting_t *root, *L1, *L2, *L3, *L4, *L5, *L6, *L7;
	int i, ret = 0, j,k;
	SysInfo *pSysInfo = (SysInfo *) Buffer;
	printf("\nReading Name Value File");
	if (pSysInfo == NULL)
		return -1;

	/*  Initialize the configuration structure(cfg) and read valid name value file */
	config_init(&cfg);
	ret = read_NameValue_cfg(&cfg);
	if (ret == FAIL) {
		ERROR_ASCII("Error reading Config File\n");
		config_destroy(&cfg);
		return -1;
	}
	/*  Read and update the system configurations from namevalue structure */
	root = config_root_setting(&cfg);
	if (NULL != (L1 = config_setting_get_member(root, REL_UNIQ_ID)))
		pSysInfo->relUniqueId = config_setting_get_int(L1);
	if (NULL != (L1 = config_setting_get_member(root, HOSTNAME)))
		strcpy(pSysInfo->hostname,config_setting_get_string(L1));
	if (NULL != (L1 = config_setting_get_member(root, NETWORK_CONFIG))) {
		if (NULL != (L2 = config_setting_get_member(L1, IP_ADDR)))
			pSysInfo->eth.ip.s_addr = inet_addr(config_setting_get_string(L2));
		if (NULL != (L2 = config_setting_get_member(L1, NET_MASK)))
			pSysInfo->eth.netmask.s_addr = inet_addr(config_setting_get_string(L2));
		if (NULL != (L2 = config_setting_get_member(L1, GATE_WAY)))
			pSysInfo->eth.gateway.s_addr = inet_addr(config_setting_get_string(L2));
		if (NULL != (L2 = config_setting_get_member(L1, DNS_ADDRESS)))
			pSysInfo->eth.dns.s_addr = inet_addr(config_setting_get_string(L2));
		if (NULL != (L2 = config_setting_get_member(L1, MAC_ADDR)))
				for (i = 0; i < MAC_LENGTH; i++) {
					if (NULL != (L3 = config_setting_get_elem(L2, i)))
						pSysInfo->eth.MAC[i] = config_setting_get_int(L3);
				}
		if (NULL != (L2 = config_setting_get_member(L1, DHCP_ENABLE)))
			pSysInfo->eth.dhcp_enable = config_setting_get_int(L2);	
	} else {
			ERROR_ASCII("Error while Reading  Network configuration from file.\n");
    }

    config_destroy(&cfg);
    return 0;
}

/*
 *  Fn     -  create_NameValue_file
 *  Brief  -  Read System Configuration and create/update namevalue configuration file
 *  Param  -  System Configuration Buffer (SysInfo)
 *  Return -  0 on Success
 */
int create_NameValue_file(void *Buffer)
{
		char cmd[64];
		config_t cfg;
		config_setting_t *root, *L1, *L2, *L3, *L4, *L5, *L6, *L7;
		int i, j, k;
		
		//printf("\nCreating Name Value File");
		SysInfo *pSysInfo = (SysInfo *) Buffer;
		if (pSysInfo == NULL) {
				ERROR_ASCII("In %s , SysInfo Returned NULL \n", __func__);
				return -1;
		}
		/*
		 *  Initialize the name value configuration structure and add the system configurations to it.
		 */
		config_init(&cfg);
		root = config_root_setting(&cfg);
		if (NULL != (L1 = config_setting_add(root, REL_UNIQ_ID, CONFIG_TYPE_INT)))
			config_setting_set_int(L1, pSysInfo->relUniqueId);
		if (NULL != (L1 = config_setting_add(root, HOSTNAME, CONFIG_TYPE_STRING)))
				config_setting_set_string(L1, pSysInfo->hostname);
		if (NULL != (L1 = config_setting_add(root, NETWORK_CONFIG, CONFIG_TYPE_GROUP))) {
				if (NULL != (L2 = config_setting_add(L1, IP_ADDR, CONFIG_TYPE_STRING)))
					config_setting_set_string(L2, inet_ntoa(pSysInfo->eth.ip));
				if (NULL != (L2 = config_setting_add(L1, NET_MASK, CONFIG_TYPE_STRING)))
					config_setting_set_string(L2, inet_ntoa(pSysInfo->eth.netmask));
				if (NULL != (L2 = config_setting_add(L1, GATE_WAY, CONFIG_TYPE_STRING)))
					config_setting_set_string(L2, inet_ntoa(pSysInfo->eth.gateway));
				if (NULL != (L2 = config_setting_add(L1, DNS_ADDRESS, CONFIG_TYPE_STRING)))
					config_setting_set_string(L2, inet_ntoa(pSysInfo->eth.dns));
				if (NULL != (L2 = config_setting_add(L1, MAC_ADDR, CONFIG_TYPE_ARRAY)))
					for (i = 0; i < MAC_LENGTH; i++) {
						if (NULL != (L3 = config_setting_add(L2, NULL, CONFIG_TYPE_INT)))
							config_setting_set_int(L3,pSysInfo->eth.MAC[i]);
					}
		if (NULL != (L2 = config_setting_add(L1, DHCP_ENABLE, CONFIG_TYPE_INT)))
					config_setting_set_int(L2,pSysInfo->eth.dhcp_enable);
		} else {
				ERROR_ASCII("Error while writing eth configuration into file.\n");
		}

        /*
         *  Write the namevalue configurations into the configuration file.
         */
		if (write_NameValue_cfg(&cfg) != 0) {
				ERROR_ASCII("Error while writing file.\n");
				config_destroy(&cfg);
				return -1;
		}
		/*
		 *  config write success,free the configuration structure.
		 */
		printf("Configuration File created successfully\n");
		config_destroy(&cfg);

		/* 
		 *	Copy the local configuration file into flash.
		 */
		sprintf(cmd, "cp -fr %s/* %s/. \n", NAMEVALUE_CFG_FOLDER_L, NAMEVALUE_CFG_FOLDER_F);
    system(cmd);	
		return 0;
}
