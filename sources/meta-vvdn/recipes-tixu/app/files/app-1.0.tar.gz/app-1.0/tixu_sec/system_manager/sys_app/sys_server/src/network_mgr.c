#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/ioctl.h>
#include <sys_env_type.h>
#include <net/if.h>
#define ZERO_IP "0.0.0.0"
#define DEBUG
#ifdef DEBUG
#define DBG(fmt, args...)   printf("Debug " fmt, ##args)
#else
#define DBG(fmt, args...)
#endif
#define ERR1(fmt, args...)  printf("Error " fmt, ##args)

/**
 *Network Configuration
 **/

void *NetworkMngThread(void *arg)
{
	char buffer[100], *ptr, cmd[100];
	FILE *fd;
	SysInfo *pSysInfo = GetSysInfo();
	wifi_config();
	/*setting eth address */
	if(pSysInfo->board.board_id == 0){
		set_eth_addr();
	}
}

/**
 *WiFi Configuration
 **/
int wifi_config()
{
	FILE *fp;
	char cmd[100];
	SysInfo *pSysInfo;
	pSysInfo = GetSysInfo();
	DBG("Wifi AP mode\n");
	wifi_configure_ap();
	return SUCCESS;
}

int wifi_configure_ap()
{
	FILE *fp;
	char cmd[100];
	SysInfo *pSysInfo;
	pSysInfo = GetSysInfo();
	DBG("Wifi configuring as AP\n");
	/*operate WLAN as AP*/
	system("ip addr flush dev wlan0");
	system("rm /etc/hostapd.conf");
	fp = fopen("/etc/hostapd.conf", "wr");
	/*Configuring hostapd.conf */
	if (pSysInfo->wifi_info.wifi_security_ap == SECURED_AP)
	{                                                                                                                             
		DBG("Configuring hostapd as Secured AP\n");
		fprintf(fp, "interface=wlan0\ndriver=nl80211\nchannel=0\nhw_mode=g\npreamble=1\ndtim_period=2\nbeacon_int=100\nlogger_syslog=-1\nlogger_syslog_level=2\nlogger_stdout=-1\nlogger_stdout_level=2\ndump_file=/tmp/hostapd.dump\nctrl_interface=/var/run/hostapd\nctrl_interface_group=0\nsupported_rates=60 90 120 180 240 360 480 540\nbasic_rates=60 90 120 180 240\nssid=BYTE\nmax_num_sta=5\nmacaddr_acl=0\nauth_algs=3\nieee80211d=0\nuapsd_advertisement_enabled=1\nwep_rekey_period=0\nown_ip_addr=127.0.0.1\nwpa_group_rekey=0\nwpa_strict_rekey=0\nwpa_gmk_rekey=0\nwpa_ptk_rekey=0\neap_server=1\ndisassoc_low_ack=1\nap_max_inactivity=4294967295\nwpa=2\nwpa_passphrase=12345678\nwpa_key_mgmt=WPA-PSK\nwpa_pairwise=TKIP\nrsn_pairwise=CCMP");
	}else {
		DBG("Configuring hostapd as Open AP\n");
		fprintf(fp, "interface=wlan0\ndriver=nl80211\nchannel=11\nhw_mode=g\npreamble=1\ndtim_period=2\nbeacon_int=100\nlogger_syslog=-1\nlogger_syslog_level=2\nlogger_stdout=-1\nlogger_stdout_level=2\ndump_file=/tmp/hostapd.dump\nctrl_interface=/var/run/hostapd\nctrl_interface_group=0\nsupported_rates=60 90 120 180 240 360 480 540\nbasic_rates=60 90 120 180 240\nssid=BYTE\nmax_num_sta=5\nmacaddr_acl=0\nauth_algs=3\nieee80211d=0\nuapsd_advertisement_enabled=1\nwep_rekey_period=0\nown_ip_addr=127.0.0.1\nwpa_group_rekey=0\nwpa_strict_rekey=0\nwpa_gmk_rekey=0\nwpa_ptk_rekey=0\neap_server=1\ndisassoc_low_ack=1\nap_max_inactivity=4294967295");
	}
	fclose(fp);
	/*Configuring udhcpd.conf*/
	system("rm /etc/udhcpd.conf");
	fp = fopen("/etc/udhcpd.conf", "wr");
	fprintf(fp,"start  10.4.30.40\nend  10.4.30.50\ninterface  wlan0\nopt dns   8.8.8.8  8.8.4.4\noption subnet  255.255.255.0\nopt router  10.4.30.34\noption lease 86400");
	fclose(fp);

	sprintf(cmd,"ifconfig wlan0 10.4.30.34 netmask 255.255.255.0 up");
	system(cmd);
	sleep(1);
	system("hostapd -B /etc/hostapd.conf -P /var/run/hostapd.pid");
	system("udhcpd /etc/udhcpd.conf");
	SaveToFlash();
	return SUCCESS;
}

/**         
 * @brief Setting ethernet addres from system configuration. 
 * @param None
 * @retval None     
 **/
void set_eth_addr(void)
{
	ETHERNET_CONFIG inet;
	char cmd[100];
	int fd;
	struct sockaddr_in sin;
	struct ifreq ifr;
	sprintf(cmd,"ifconfig eth0 up");
	system(cmd);

	// Reading the SysInfo 
	SysInfo *LocalSysInfo = GetSysInfo();
	inet.ip=LocalSysInfo->eth.ip;
	inet.netmask=LocalSysInfo->eth.netmask;
	inet.gateway=LocalSysInfo->eth.gateway;

	fd = socket(AF_INET, SOCK_DGRAM, 0);
	strcpy(ifr.ifr_name, "eth0");
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet.ip.s_addr;
	memcpy(&ifr.ifr_addr, &sin, sizeof(struct sockaddr));

	ioctl(fd, SIOCSIFADDR, &ifr);
	sin.sin_addr.s_addr = inet.netmask.s_addr;
	memcpy(&ifr.ifr_addr, &sin, sizeof(struct sockaddr));
	ioctl(fd, SIOCSIFNETMASK, &ifr);
	close(fd);
}

