#include "zbha_api.h"
#include "base.h"
#include "log.h"
#include "buffer.h"
#include "plugin.h"
#include <sysctrl.h>
#include "server.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <Msg_Def.h>
#include <Sys_Msg_Def.h>
#include <sys_log.h>

//
//
//	To print anything on console, dbg(<Arguments>);
//
//

/* plugin config for all request/connections */

//plugin_config structure holds plugin configurations according to lighttpd.conf in /etc/lighttpd/lighttpd.conf


extern server *server_zbha;
extern connection *connection_zbha;

typedef struct {
	array *match;
} plugin_config;

//plugin_data structure holds all data for plugin from server

typedef struct {
	PLUGIN_DATA;

	buffer *match_buf;

	plugin_config **config_storage;

	plugin_config conf;
} plugin_data;

typedef struct {
	size_t foo;
} handler_ctx;

static handler_ctx * handler_ctx_init() {
	handler_ctx * hctx;

	hctx = calloc(1, sizeof(*hctx));

	return hctx;
}

static void handler_ctx_free(handler_ctx *hctx) {

	free(hctx);
}

/* init the plugin data */
INIT_FUNC(mod_zbha_init) {
	plugin_data *p;
	p = calloc(1, sizeof(*p));

	p->match_buf = buffer_init();
	if(SysDrvInit(SYS_LHTTP_MSG_SET,SYS_LHTTP_MSG_GET,1) < 0) 
	{
		dbg("SYS Message Drive error");
		exit(1);
	}
	if(InitFileMsgDrv(FILE_MSG_KEY, FILE_LTY_MSG) < 0)
	{
		dbg("FILE Message Drive error");
		exit(1);
	}
	hash_table_init();

	return p;
}

/* destroy the plugin data */
FREE_FUNC(mod_zbha_free) {
	plugin_data *p = p_d;
	UNUSED(srv);

	if (!p) return HANDLER_GO_ON;

	if (p->config_storage) {
		size_t i;

		for (i = 0; i < srv->config_context->used; i++) {
			plugin_config *s = p->config_storage[i];

			if (!s) continue;

			array_free(s->match);

			free(s);
		}
		free(p->config_storage);
	}

	buffer_free(p->match_buf);

	free(p);

	return HANDLER_GO_ON;
}

/* handle plugin config and check values */

SETDEFAULTS_FUNC(mod_zbha_set_defaults) {
	plugin_data *p = p_d;
	size_t i = 0;
	config_values_t cv[] = {
		{ "zbha.array",             NULL, T_CONFIG_ARRAY, T_CONFIG_SCOPE_CONNECTION },       /* 0 */
		{ NULL,                         NULL, T_CONFIG_UNSET, T_CONFIG_SCOPE_UNSET }
	};

	if (!p) return HANDLER_ERROR;

	p->config_storage = calloc(1, srv->config_context->used * sizeof(specific_config *));

	for (i = 0; i < srv->config_context->used; i++) {
		plugin_config *s;

		s = calloc(1, sizeof(plugin_config));
		s->match    = array_init();

		cv[0].destination = s->match;

		p->config_storage[i] = s;

		if (0 != config_insert_values_global(srv, ((data_config *)srv->config_context->data[i])->value, cv)) {
			return HANDLER_ERROR;
		}
	}

	return HANDLER_GO_ON;
}

#define PATCH(x) \
	p->conf.x = s->x;
static int mod_zbha_patch_connection(server *srv, connection *con, plugin_data *p) {
	size_t i, j;
	plugin_config *s = p->config_storage[0];

	PATCH(match);

	/* skip the first, the global context */
	for (i = 1; i < srv->config_context->used; i++) {
		data_config *dc = (data_config *)srv->config_context->data[i];
		s = p->config_storage[i];

		/* condition didn't match */
		if (!config_check_cond(srv, con, dc)) continue;

		/* merge config */
		for (j = 0; j < dc->value->used; j++) {
			data_unset *du = dc->value->data[j];

			if (buffer_is_equal_string(du->key, CONST_STR_LEN("zbha.array"))) {
				PATCH(match);
			}
		}
	}

	return 0;
}


#undef PATCH

//This function is called by server when a uri is received by the server from the client

URIHANDLER_FUNC(mod_zbha_uri_handler) 
{
	plugin_data *p = p_d;
	int s_len, flag = 0;
	size_t k,i,j;
	UNUSED(srv);
	HTTP_REQ_DECODE query_decoded;
	HTTP_OPTION *zbha_cmd;
#ifdef CONFIG_SCHEME
	SysInfo* pSysInfo;
#endif

	if (con->mode != DIRECT) return HANDLER_GO_ON;

	if (con->uri.path->used == 0) return HANDLER_GO_ON;

	mod_zbha_patch_connection(srv, con, p);

	s_len = con->uri.path->used - 1;

	for (k = 0; k < p->conf.match->used; k++)
	{
		data_string *ds = (data_string *)p->conf.match->data[k];
		int ct_len = ds->value->used - 1;
		if (ct_len > s_len) continue;
		if (ds->value->used == 0) continue;

		if (0 == strncmp(con->uri.path->ptr + s_len - ct_len, ds->value->ptr, ct_len)) 
		{
				server_zbha = srv;
				connection_zbha = con;
				//Plugin parses query string to get command and arguments from HTTP request
				if(parse_zbha_rest(connection_zbha, con->uri.path->ptr, con->uri.query->ptr, &query_decoded) < 0)
				{
					sprintf(response_string, OPTION_ERROR "%s=%s\n", con->uri.query->ptr);
					send_to_client(response_string);
					con->http_status = 200;
					con->file_finished = 1;
					return HANDLER_FINISHED;
				}
				for(i=0;i<query_decoded.cmd_count;i++)
				{				
					//Command received from querystring is searched in the hash table
					zbha_cmd = http_option_search(query_decoded.cmd_arg[i].name);
					if(zbha_cmd == NULL)
					{
						sprintf(response_string, OPTION_UNKNOWN "PATH=%s QUERY=%s \n",con->uri.path_raw->ptr, query_decoded.cmd_arg[i].name);
						send_to_client(response_string);
						break;
					}
#ifdef ZBHA
					con->authority = AUTHORITY_ADMIN;	//testing. authority should be updated from sysInfo.
					if(con->authority <= zbha_cmd->authority)
#endif
					{
#ifdef CONFIG_SCHEME
						pSysInfo = GetSysInfo();
						if (pSysInfo == NULL)
						{
							break;
						}
						//Calls  correspoding function to execute the command received
						for (j = 0; j < 10; j++)
						{
				//			if (!strcmp(con->authed_user->ptr, pSysInfo->account[j].user_name.value))
							{
				//				dbg("\nUser at client side : %s", pSysInfo->account[j].user_name.value);
				//				flag = 1;
				//				break;
							}
						}
#endif
						if(!flag)
						{
							(zbha_cmd->handler)(&query_decoded.cmd_arg[i]);
						}
					}
				}
				con->http_status = 200;
				con->file_finished = 1;
				return HANDLER_FINISHED;
		}

	}
	/* Request was not for this plugin */
	return HANDLER_GO_ON;
}

/* this function is called at dlopen() time and inits the callbacks */

int mod_zbha_plugin_init(plugin *p) {

	p->version     = LIGHTTPD_VERSION_ID;
	p->name        = buffer_init_string("zbha");

	p->init        = mod_zbha_init;
	p->handle_uri_clean  = mod_zbha_uri_handler;
	p->set_defaults  = mod_zbha_set_defaults;
	p->cleanup     = mod_zbha_free;

	p->data        = NULL;

	return 0;
}
