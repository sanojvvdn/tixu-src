/* ymodem for RTD Serial Recovery (rtdsr)
 *
 * copyright (c) 2011 Pete B. <xtreamerdev@gmail.com>
 *
 * based on ymodem.c for bootldr, copyright (c) 2001 John G Dorsey
 * baded on ymodem.c for reimage, copyright (c) 2009 Rich M Legrand
 * crc16 function from PIC CRC16, by Ashley Roll & Scott Dattalo
 * crc32 function from crc32.c by Craig Bruce
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 */
#include "ymodem.h"
#include <termios.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <errno.h>

#define TTY "/dev/ttymxc2"
#define SUCCESS 0
#define FAIL -1
#define FOR_LOOP_CYCLE         200000
#define SLEEP_TIME 200

int serialPortFd = -1;
unsigned int active_baudrate = B115200;
typedef unsigned char   uint8_t;
typedef unsigned short  uint16_t;

/*
 * @func    :Writetotty()
 * @brief   :This function is called by _putchar to write a char to ttymxc2
 */
int Writetotty(int fd,uint8_t *buf,uint8_t Len)
{
	int ret=0;
	while(Len--)
	{
		ret=write(fd, buf,1);
		if(ret == 1) {
			usleep(SLEEP_TIME);
		}
		if(ret < 0) {
			return FAIL;
		}
	}
	return SUCCESS;
}

/*
 * @func    :Readfromtty()
 * @brief   :This function is called by _getchar to read a character from ttymxc2
 */
int Readfromtty(int fd, uint8_t buf, unsigned int Len)
{
	do
	{
		if(1 == read(fd, &buf, 1)) {
			break;
		}
	} while (1);
	return buf;
}
/*
 * @func    :UpdateBaudrate()
 * @brief   :This function is called for updating Baudrate of ttymxc2 to 115200
 * @args    :baudrate
 */
void UpdateBaudrate(unsigned int baudrate)
{
	struct termios tio;

	tio.c_cflag = baudrate | CS8 | CLOCAL | CREAD;
	tio.c_iflag = IGNPAR & ~ICRNL;
	tio.c_oflag = 0;
	tio.c_lflag = 0;
	tcsetattr(serialPortFd,TCSANOW,&tio);
}
/*
 * @func    :Set_tty()
 * @brief   :This function is called for setting the ttymxc2 on nonblocking mode
 * @args    :ttyname
 */
int Set_tty( char *devicePath  )
{
	/* open the ttymxc2 on nonblocking mode */
	serialPortFd = open(devicePath, O_RDWR | O_NOCTTY | O_NONBLOCK);
	if (serialPortFd < 0) {
		perror(devicePath);
		return FAIL;
	}
	/* making access to ttymxc2 exclusive */
	ioctl(serialPortFd, TIOCEXCL);
	tcflush(serialPortFd, TCIFLUSH);
	UpdateBaudrate(active_baudrate);
	return SUCCESS;
}
/*
 * @func    :Opentty()
 * @brief   :This function is called for Opening ttymxc2
 * @args    :baudrate
 */
int Opentty( char *devicePath  )
{
	if (Set_tty(devicePath) == FAIL) {
		perror(devicePath);
		printf("%s open failed\n",devicePath);
		return FAIL;
	}
	return SUCCESS;
}

static const char *u32_to_str(unsigned int val)
{
	/* Maximum number of decimal digits in u32 is 10 */
	static char num_str[11];
	int  pos = 10;
	num_str[10] = 0;

	if (val == 0) {
		/* If already zero then just return zero */
		return "0";
	}

	while ((val != 0) && (pos > 0))
	{
		num_str[--pos] = (val % 10) + '0';
		val /= 10;
	}

	return &num_str[pos];
}

void _sleep(int seconds)
{
	unsigned long i;
	for (i=0; i<FOR_LOOP_CYCLE*seconds; i++);
}
/*
 * @func    :crc16()
 * @brief   :implementation of the CRC16 algorithm with the CCITT polynomial
 */
/* http://www.ccsinfo.com/forum/viewtopic.php?t=24977 */
static unsigned short crc16(const unsigned char *buf, unsigned long count)
{
	unsigned short crc = 0;
	int i;

	while(count--) {
		crc = crc ^ *buf++ << 8;

		for (i=0; i<8; i++) {
			if (crc & 0x8000) {
				crc = crc << 1 ^ 0x1021;
			} else {
				crc = crc << 1;
			}
		}
	}
	return crc;
}
/*
 * @func    :_putchar()
 * @brief   :Sends a character
 */
void _putchar(int c)
{
	char b = c & 0xFF;
	int ret=2;
	ret = Writetotty(serialPortFd,&b,1);
	if(ret == FAIL) {
		printf(" FAIL ON WRITING \n");
	}
}
/*
 * @func    :_getchar()
 * @brief   :Get a character with a timeout in seconds.
 */
int _getchar(int timeout)
{
	int i, c=2;
	uint8_t buf;
	c = Readfromtty(serialPortFd, buf, 1);

	if( c >= 0) {
		return c;
	}
	printf(" FAIL ON READING \n");
	return FAIL;
}
/*
 * @func    :send_packet()
 * @brief   :Send data in packet byte by byte
 */
static void send_packet(unsigned char *data, int block_no)
{
	int count, crc, packet_size;

	/* We use a short packet for block 0 - all others are 1K */
	if (block_no == 0) {
		packet_size = PACKET_SIZE;
	} else {
		packet_size = PACKET_1K_SIZE;
	}
	crc = crc16(data, packet_size);
	/* 128 byte packets use SOH, 1K use STX */
	_putchar((block_no==0)?SOH:STX);
	_putchar(block_no & 0xFF);
	_putchar(~block_no & 0xFF);

	for (count=0; count<packet_size; count++)
	{
		_putchar(data[count]);
	}
	_putchar((crc >> 8) & 0xFF);
	_putchar(crc & 0xFF);
}
/*
 * @func    :send_packet0()
 * @brief   :Send block 0 (the filename block). filename might be truncated to fit.
 */
static void send_packet0(char* filename, unsigned long size)
{
	unsigned long count = 0;
	unsigned char block[PACKET_SIZE];
	const char* num;

	if (filename) {
		while (*filename && (count < PACKET_SIZE-FILE_SIZE_LENGTH-2))
		{
			block[count++] = *filename++;
		}
		block[count++] = 0;

		num = u32_to_str(size);
		while(*num)
		{
			block[count++] = *num++;
		}
	}
	while (count < PACKET_SIZE)
	{
		block[count++] = 0;
	}
	send_packet(block, 0);
}
/*
 * @func    :send_data_packets()
 * @brief   :Send 1k byte length data packets
 */
static void send_data_packets(unsigned char* data, unsigned long size)
{
	int blockno = 1;
	unsigned long send_size;
	int ch;

	while (size > 0)
	{
		if (size > PACKET_1K_SIZE) {
			send_size = PACKET_1K_SIZE;
		} else {
			send_size = size;
		}

		send_packet(data, blockno);
		ch = _getchar(PACKET_TIMEOUT);
		if (ch == ACK) {
			blockno++;
			data += send_size;
			size -= send_size;
		} else {
			if((ch == CAN) || (ch == -1)) {
				return;
			}
		}
	}
	do
	{
		_putchar(EOT);
		ch = _getchar(PACKET_TIMEOUT);
	} while((ch != ACK) && (ch != -1));

	/* Send last data packet */
	if (ch == ACK) {
		if (ch == CRC) {
			do
			{
				send_packet0(0, 0);
				ch = _getchar(PACKET_TIMEOUT);
			} while((ch != ACK) && (ch != -1));
		}
	}
}
/*
 * @func    :zigbee_restart()
 * @brief   :Making the CC2538 restart
 */
void zigbee_restart(void)
{
	int pin_no = 47,value_zero = 0,value_one = 1;
	char dir[5];
	char buffer[50];

	strcpy(dir,"out");
	sprintf(buffer, "echo %d > /sys/class/gpio/export", pin_no);
	system(buffer);
	sprintf(buffer, "echo %s > /sys/class/gpio/gpio%d/direction", dir, pin_no);
	system(buffer);
	sprintf(buffer,"echo %d > /sys/class/gpio/gpio%d/value",value_one,pin_no);
	system(buffer);
	sprintf(buffer,"echo %d > /sys/class/gpio/gpio%d/value",value_zero,pin_no);
	system(buffer);
	sleep(1);
	sprintf(buffer,"echo %d > /sys/class/gpio/gpio%d/value",value_one,pin_no);
	system(buffer);
	sprintf(buffer, "echo %d > /sys/class/gpio/unexport", pin_no);
	system(buffer);
}
/*
 * @func    :ymodem_send()
 * @brief   :Responsible for sending file in ymodem-1K protocol
 */
unsigned long ymodem_send(unsigned char* buf, unsigned long size, char* filename)
{
	int ch, crc_nak = 1,c;
	FILE *fpin;
	printf("Ymodem send:\n");
	/* Flush the RX FIFO, after a cool off delay */
	_sleep(1);
	/* Not in the specs, just for balance */
	do
	{
		ch = _getchar(1);
	} while (ch < 0);
	if(ch == CRC)
		_putchar(SYN_3);
	usleep(SLEEP_TIME);
	if (ch == CRC) {
		do
		{
			send_packet0(filename, size);
			/* When the receiving program receives this block and successfully
			 * opened the output file, it shall acknowledge this block with an ACK
			 * character and then proceed with a normal XMODEM file transfer
			 * beginning with a "C" or NAK tranmsitted by the receiver.
			 */
			ch = _getchar(PACKET_TIMEOUT);

			if (ch == ACK) {
				ch = _getchar(PACKET_TIMEOUT);
				if (ch == CRC) {
					send_data_packets(buf, size);
					printf("\nsent:%s\n", filename);
#ifdef WITH_CRC32
					printf("crc32:0x%08x, len:0x%08x\n", crc32(buf, size), size);
#else
					printf("len:0x%08x\n", size);
#endif
					printf(" FILE UPLOAD SUCCESS \n");
					return size;
				}
			} else if ((ch == CRC) && (crc_nak)) {
				crc_nak = 0;
				continue;
			} else if ((ch != NAK) || (crc_nak)) {
				break;
			}
		} while(1);
	}
	_putchar(CAN);
	_putchar(CAN);
	_sleep(1);
	return 0;
}
/*
 * @func    :ymodem_ack()
 * @brief   :Making the CC2538 wait for firmware upgradation
 */
void ymodem_ack(void)
{
	int ch;

	while(ch != SYN_2)
	{
		_putchar(SYN_1);
		ch = _getchar(1);
	}
}

void main() 
{
	char selected_serial_port[20];
	FILE *fd;
	char buffer[512];
	unsigned long return_value;
	int ret_open;

	system("killall -15 sh ./zigbeeHAgw bbb");
	sleep(30);
	FILE *f = fopen("/tmp/upgrade/ZNP.bin", "rb");
	fseek(f, 0, SEEK_END);
	long fsize = ftell(f);
	fseek(f, 0, SEEK_SET);
	char *string = malloc(fsize + 1);
	if (string == 0)
	{
		printf("ERROR: Out of memory\n");
		fclose(f);
		return;
	}
	fread(string, fsize, 1, f);
	fclose(f);
	string[fsize] = 0;
	strcpy(selected_serial_port, "/dev/ttymxc2");
	ret_open = Opentty( TTY );
	if (ret_open == FAIL) {
		free(string);
		exit(0);
	}
	zigbee_restart();
	ymodem_ack();
	ymodem_send((unsigned char*)string,fsize,"ZNP.bin");
	free(string);
}
