/* ===========================================================================
 * @file system_control.c
 *
 * @path sys_app/sys_server/src
 *
 * @desc Send commands to system server.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <system_control.h>
#include <net/if.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/sem.h>
#include <sys/ipc.h>
#include <arpa/inet.h>
#include <linux/sockios.h>
#include <netinet/in.h>
#include "file_msg_drv.h"
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <sem_util.h>
#include <system_default.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include "wdm_lib.h"
#include <sys/statfs.h>
#include <sys/mman.h>
#include <sys/statfs.h>
#include <sys_env_type.h>
#include <net/route.h>
#include <sys_log.h>
#include <sysctrl.h>
#include <cJSON.h>
#include <network_mgr.h>
#define DROP_FILESYS_CMD	"echo 1 > /proc/sys/vm/drop_caches"
#define DISK_MNT_PATH		"/media/sda1"
#define SYS_CTRL_DEBUG
#define SYS_CTRL_ERROR
#define ZERO_IP "0.0.0.0"
#ifdef SYS_CTRL_DEBUG
#define DBG(fmt, args...)	fprintf(stderr, fmt, ##args)
#else
#define DBG(fmt, args...)
#endif

#ifdef SYS_CTRL_ERROR
#define __E(fmt, args...) fprintf(stderr, "Error: " fmt, ## args)
#else
#define __E(fmt, args...)
#endif

unsigned char restart_flag = 0;
unsigned char save_config_flag = 0;
unsigned char default_flag = 0;
static SemHandl_t hndlSysSem = NULL;
static SysInfo* gpSysInfo;


#define KEY (1492)
#define KEY_NOTIFY_SEM (1729)

/*	@fn: char *get_ipaddr(char *ifname_)
 *  @brief
 *  Function to get IP.
 *  Arguments :ifname_ interface name
 *  Return
 *  success : IP address
 *  fail    : NULL
 *  */
char *get_ipaddr(char *ifname_)
{
	struct ifreq ifr;
	struct sockaddr_in *saddr;
	struct in_addr addr;
	unsigned long long_address;;
	int skfd;

	if ((skfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		return ZERO_IP;
	}
	strncpy(ifr.ifr_name, ifname_, IFNAMSIZ);
	if (ioctl(skfd, SIOCGIFADDR, &ifr) < 0) {
		close(skfd);
		return ZERO_IP;
	}
	close(skfd);
	saddr = (struct sockaddr_in *) &ifr.ifr_addr;
	long_address = (in_addr_t)saddr->sin_addr.s_addr;
	addr.s_addr = long_address;
	return inet_ntoa(addr);
}

/**
 * @biief If restart.
 *
 * @return restart flag.
 */
int IsRestart()
{
	int ret;
	SemWait(hndlSysSem);
	ret = restart_flag;
	SemRelease(hndlSysSem);
	return ret;
}


void SetRestart()
{

	SemWait(hndlSysSem);
	restart_flag = 1;
	SemRelease(hndlSysSem);
}

/**
 * @brief Clean restart flag.
 *
 */
void CleanRestart()
{
	SemWait(hndlSysSem);
	restart_flag = 0;
	SemRelease(hndlSysSem);
}

int IsResetDefault()
{
	int ret;
	SemWait(hndlSysSem);
	ret = default_flag;
	SemRelease(hndlSysSem);
	return ret;
}

int SetDefault()
{
	SemWait(hndlSysSem);
	default_flag = 1;
	SemRelease(hndlSysSem);
	return SUCCESS;
}

void CleanSetDefault()
{
	SemWait(hndlSysSem);
	default_flag = 0;
	SemRelease(hndlSysSem);
}

int IsSaveConfiguration()
{
	int ret;
	SemWait(hndlSysSem);
	ret = save_config_flag;
	SemRelease(hndlSysSem);
	return ret;
}
void SetSaveConfiguration()
{
	SemWait(hndlSysSem);
	save_config_flag = 1;
	SemRelease(hndlSysSem);
}
void CleanSaveConfiguration()
{
	SemWait(hndlSysSem);
	save_config_flag = 0;
	SemRelease(hndlSysSem);
}

/**
 *  * @brief Set System Reboot Start
 *   */
int SysSetRebootStart()
{
	//   To be done
	//   Set reboot_reason to EEPROM*/
	sleep(1);
	system("/sbin/reboot");
	return SUCCESS;
}

/**
 * @brief System server thread
 */
static void *PollingThread(void *arg){

	int ping_time_counter = 0;

	//SysInfo *pSysInfo = GetSysInfo(); //To be added once configuration scheme is ready

	//system("mkdir -p /tmp/uploaded_cfg");
	//system("mkdir -p /mnt/nand/uploaded_cfg/");
	printf("\n\rPolling Thread Started\n");
	while(1)
	{
		if(IsSaveConfiguration()) {
			ParamSaveToFlash(1);
			CleanSaveConfiguration();
		}
		if(IsResetDefault()){
			printf("\nReset Config Data to Default!!\n");
			CleanSetDefault();
			fResetSysInfo();
			SetRestart();
		}
		if (restart_flag == 1){
			printf("\nSystem is going to reboot!!\n");
			SysSetRebootStart();  
		}
		sleep(1);
	}
	return NULL;
}

/**
 * @brief Initial system
 *
 * @retval 0 Success
 * @retval -1 System initial error
 */
int SystemInit()
{

	pthread_t thread;
	SysInfo *pSysInfo = GetSysInfo(); /*To be added once configuration scheme is ready */

	if(pSysInfo == NULL){
		printf("System_init:: GetSys info failed\n");
		CleanupFileMsgDrv();
		return FAILURE;
	}

	if((hndlSysSem = MakeSem()) == NULL){
		CleanupFileMsgDrv();
		pSysInfo = NULL;
		printf("SystemInit2\n");
		return FAILURE;
	}
	pthread_create(&thread, NULL, PollingThread, NULL);
	system(DROP_FILESYS_CMD);
	return SUCCESS;
}

/********** TIXU api's*******************/
int SysGetTest(COMMAND_ARGUMENT *buffer)
{
	printf("SysGetTest\n");
	cJSON *root;

	//Copy the parameters to string
	root=cJSON_CreateObject();
	cJSON_AddNumberToObject(root,"value",10);
	strcpy((char *) buffer->value, cJSON_Print(root));
	cJSON_Delete(root);

	return SUCCESS;
}

int SysCreateTest(COMMAND_ARGUMENT *buffer)
{
	printf("SysCreateTest:  Received data =%s\n",buffer->value);
	return SUCCESS;
}

int SysSetTest(COMMAND_ARGUMENT *buffer)
{
	printf("SysSetTest:  Received data =%s\n",buffer->value);
	cJSON *root, *param;
	int value, ret = SUCCESS;

	root = cJSON_Parse((char *) buffer->value);
	if(root != NULL) {
		param = cJSON_GetObjectItem(root,"value");
		if(param != NULL) {
			value = param->valueint;
			printf("value received is = %d\n",value);
			cJSON_Delete(root);
			root=cJSON_CreateObject();
			cJSON_AddStringToObject(root,"SUCCESS",buffer->value);
			strcpy((char *) buffer->value, cJSON_Print(root));
			cJSON_Delete(root);

		} else {
			printf("param is NULL\n");
			ret = -1;
		}
	} else {
		printf("root is NULL\n");
		ret = -1;
	}
	return ret;
}

int SysDeleteTest(COMMAND_ARGUMENT *buffer)
{
	printf("SysDeleteTest\n");
	return SUCCESS;
}

/*
 * @func    :SysGetGatewayParams()
 * @brief   :This function is called to get Gateway info such as version.
 * @args    :COMMAND_ARGUMENT structure
 * @return  :
 * SUCCESS  : When function executed successfully
 * FAILURE  : when an error occured.
 * */

int SysGetGatewayParams(COMMAND_ARGUMENT *buffer)
{
	cJSON *root;
	root = cJSON_CreateObject();
	SysInfo *pSysInfo = GetSysInfo();

	if (pSysInfo == NULL) {
		DBG("SysInfo error\n");
		root = cJSON_CreateObject();
		cJSON_AddStringToObject(root , "Return" , "FAILURE: SysInfo error");
		strcpy((char *) buffer->value , cJSON_Print(root));
		cJSON_Delete(root);
		return FAILURE;
	}
	cJSON_AddStringToObject(root , "Firmware Version" , pSysInfo->firmware_version);
	strcpy((char *) buffer->value , cJSON_Print(root));
	cJSON_Delete(root);

	return SUCCESS;
}
/*
 * @func    :SysSetGatewayReboot()
 * @brief   :This function is called to reboot the Gateway.
 * @args    :COMMAND_ARGUMENT structure
 * @return  :
 * SUCCESS  : When function executed successfully
 * FAILURE  : when an error occured.
 */
int SysSetGatewayReboot(COMMAND_ARGUMENT *buffer)
{
	cJSON *root, *param;
	root = cJSON_CreateObject();
	int boot = 0, ret;
	printf("Received data is %s\n", buffer->value);
	root = cJSON_Parse((char *) buffer->value);
	if (root != NULL) {
		param = cJSON_GetObjectItem(root, "reboot");
		if (param != NULL) {
			boot = param->valueint;
			if (boot == 1) {
				printf("board is rebooting\n");
				system("/sbin/shutdown -r now");
				cJSON_Delete(root); 
				root = cJSON_CreateObject();
				cJSON_AddStringToObject(root , "Return" , "Success");
				strcpy((char *) buffer->value , cJSON_Print(root));
				cJSON_Delete(root);
				return SUCCESS;
			} else {
				cJSON_Delete(root);
				root = cJSON_CreateObject();
				cJSON_AddStringToObject(root , "Return" , "Failure");
				strcpy((char *) buffer->value , cJSON_Print(root));
				cJSON_Delete(root);
				return SUCCESS;
			}
		} else {
			printf("Param is NULL\n");
			ret -1;
		}
	} else {
		printf("Root is NULL\n");
		ret -1;
	}
	cJSON_Delete(root);
	return SUCCESS;
}

/*****************************************/
/**
 * @brief Clean up system message driver
 *
 */
void SystemCleanup(void)
{
	DestroySem(hndlSysSem);
	hndlSysSem = NULL;
	CleanupFileMsgDrv();
}

/**         
 * @brief Set this variable to Save Configuration to flash
 * @param value (not used now)
 * @retval 0:SUCCESS     
 * @retval -1:FAIL       
 */         
int SaveConfiguration()
{  
	SetSaveConfiguration();
	return SUCCESS;
}

/**
 * @brief Save Configuration to flash
 * @param value (not used now)
 * @retval 0:SUCCESS
 * @retval -1:FAIL
 */
int ParamSaveToFlash(int value)
{
	int ret;
	ret = SaveToFlash();
	return ret;
}
