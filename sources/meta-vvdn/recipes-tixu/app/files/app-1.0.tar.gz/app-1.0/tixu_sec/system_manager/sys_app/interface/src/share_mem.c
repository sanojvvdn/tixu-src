/* ===========================================================================
 * @file share_mem.c
 *
 * @path sys_app/interface/src
 *
 * @desc This creates a communication interface using share memeory
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include "share_mem.h"
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys_env_type.h>

#ifdef DEBUG
#define __D(fmt, args...) fprintf(stderr, "Debug: " fmt, ## args)
#else
#define __D(fmt, args...)
#endif

static int mid;
/**
 * @brief Initialize shared memory driver.

 * Initialize shared momory driver.
 * @note Once initialed, the memory ID is saved to global variable.
 * @return Memory ID
 * @retval -1 Fail to initialize shared memory.
 */
int ShareMemInit(int key)
{
	mid = shmget(key, PROC_MEM_SIZE * MAX_SHARE_PROC, IPC_CREAT | 0660);
	if(mid < 0)
		mid = shmget(key, 0, 0);
	__D("shared memory id:%d\n",mid);
	if(mid < 0)
		return -1;
	return mid;
}
/**
 * @brief Initialize pshared memory driver.

 * Initialize pshared momory driver.
 * @note The memory ID isn't saved to global variable.
 * @return Memory ID
 * @retval -1 Fail to initialize shared memory.
 */
int pShareMemInit(int key)
{
	int mid = shmget(key, PROC_MEM_SIZE * MAX_SHARE_PROC, IPC_CREAT | 0660);
	__D("shared memory size %d\n", PROC_MEM_SIZE * MAX_SHARE_PROC);
	if(mid < 0)
		mid = shmget(key, 0, 0);
	__D("shared memory id:%d\n",mid);
	if(mid < 0)
		return -1;
	return mid;
}
/**
 * @brief Read shared memory driver.

 * Read shared momory.
 * @param offset [i]  memory offset
 * @param *buf [i]  pointer to memory buffer
 * @param length [i]  data length to read
 */
int ShareMemRead(int offset,void *buf, int length)
{
	char *pSrc = shmat(mid,0,0);
	__D("%s\n",__func__);
	__D("offset: %d\n", offset);
	__D("buf: %x\n", (unsigned int) buf);
	__D("length: %d\n", length);
	if(pSrc == FAILURE)
		return FAILURE;
	memcpy(buf, pSrc + offset, length);
	if(shmdt(pSrc) == FAILURE)
		return FAILURE;
	return SUCCESS;
}
/**
 * @brief Write shared memory driver.

 * Write shared momory.
 * @param offset [i]  memory offset
 * @param *buf [i]  pointer to memory buffer
 * @param length [i]  data length to read
 */
int ShareMemWrite(int offset,void *buf, int length)
{
	char *pDst = shmat(mid,0,0);
	__D("%s\n",__func__);
	__D("offset: %d\n", offset);
	__D("buf: %x\n", (unsigned int) buf);
	__D("length: %d\n", length);
	__D("pDst: %p\n", pDst);
	__D("pDst + offset: %p\n", pDst + offset);
	if(pDst == FAILURE)
		return FAILURE;
	memcpy(pDst + offset, buf, length);
	if(shmdt(pDst) == FAILURE)
		return FAILURE;
	return SUCCESS;
}
