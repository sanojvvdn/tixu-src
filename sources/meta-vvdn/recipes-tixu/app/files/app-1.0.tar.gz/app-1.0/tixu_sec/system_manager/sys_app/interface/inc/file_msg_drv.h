/* ===========================================================================
 * @file file_msg_drv.h
 *
 * @path $sys_app/interface/inc
 *
 * @desc his is the communication interface of file manager. Every process needs a
 *  message ID (which is defined in @ref File_Msg_Def.h) to communicate with
 * file manager. 
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/

/* _FILE_MSG_DRV_H_ */
/**
* @page FILE_MSG_DRV_HOW How to use file message driver?

* 1. Add new message ID in \ref File_Msg_Def.h if needed.\n
* 2. Call the API InitFileMsgDrv(int key,int iProcId) with the ID you added to initialize file
*  message driver.\n
* 3. Now you can use any file message driver functions as you want.\n
* 4. Call the API CleanupFileMsgDrv() to cleanup file message driver.
* @section FILE_MSG_DRV_HOW_EX Example
* 
#include <file_msg_drv.h>
int main()
{
	SysInfo *pSysInfo;
	if( InitFileMsgDrv(FILE_MSG_KEY, FILE_SYS_MSG) != 0)
		return -1;
	pSysInfo = GetSysInfo();
	// more file message driver API
	CleanupFileMsgDrv();
	return 0;
}
*/
#ifndef _FILE_MSG_DRV_H_
#define _FILE_MSG_DRV_H_
#include <Msg_Def.h>
#include <sys_env_type.h>

/* This function should be called at process innitial !!! */
int InitFileMsgDrv(int key,int iProcId);
void CleanupFileMsgDrv();
/* API */
int fSetTitle(void *buf, int len);
int fSetWifiMode(int mode);
void SendFileQuitCmd();
SysInfo *GetSysInfo();

#endif 

