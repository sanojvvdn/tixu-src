/* ===========================================================================
 * @file Name_property.c
 *
 * @path $SystemServer/src/
 *
 * @desc This file contains the name propery value interface for libconfig.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include <name_property.h>
#include <libconfig.h>
#include <file_mng_ascii.h>

//#define DEBUG
#ifdef DEBUG
#define DBG(fmt, args...) printf(fmt, ##args)
#else
#define DBG(fmt, args...)
#endif

/*
 *  Fn     - read_type_string
 *  Brief  - read a parameter of type string from the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int read_type_string(config_setting_t *addr, TXT_S *str_ptr)
{
	int len;

	len = strlen(config_setting_get_string(addr));
	if(len > str_ptr->limit) {
		DBG("Name PPT String Read ERROR: String lenth limit exceeded");
		return -1;
	}
	
	strcpy(str_ptr->value,config_setting_get_string(addr));

	return 0;
}

/*
 *  Fn     - read_type_integer
 *  Brief  - read a parameter of type integer from the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int read_type_integer(config_setting_t *addr, INT_VAR *ptr)
{
	int temp;

	temp = config_setting_get_int(addr);
	if ((ptr->min > temp) || (ptr->max < temp)) {
		DBG("Name PPT Integer Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	ptr->value = temp;

	return 0;
}

/*
 *  Fn     - read_type_bool
 *  Brief  - read a parameter of type booelan from the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int read_type_bool(config_setting_t *addr, BOOLN *ptr)
{
	 int temp;

	temp = config_setting_get_int(addr);
	if ((temp != _FALSE) && (temp!= _TRUE))	{
		DBG("Name PPT Bool Read ERROR: Not a boolean value");
		return -1;
	}
	ptr->value = temp;

	return 0;
}

/*
 *  Fn     - read_type_float
 *  Brief  - read a parameter of type float from the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int read_type_float(config_setting_t *addr, FL_VAR *ptr)
{
	 float temp;

	temp = config_setting_get_float(addr);
	if ((ptr->min > temp) || (ptr->max < temp)) {
		DBG("Name PPT Float Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	ptr->value = temp;

	return 0;
}

/*
 *  Fn     - read_type_setn
 *  Brief  - read a parameter of type setn from the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int read_type_setn(config_setting_t *addr, SET_N *ptr)
{
	int temp;

	temp = config_setting_get_int(addr); 
	if(temp > ptr->max) {
		DBG("Name PPT Cuurent Index Read ERROR: Min/Max limit exceeded");
		return -1;
	}	
	ptr->current_index = temp;

	return 0;
}

/*
 *  Fn     - read_type_time
 *  Brief  - read a parameter of type time from the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int read_type_time(config_setting_t *addr, TIME_VAR *ptr)
{
	config_setting_t *addr1;
	int hour, min, sec, mode;
	if (NULL != (addr1 = config_setting_get_member(addr, TIME_MODE)))
		mode = config_setting_get_int(addr1);
	if (NULL != (addr1 = config_setting_get_member(addr, TIME_HOUR)))
		hour = config_setting_get_int(addr1);
	if (NULL != (addr1 = config_setting_get_member(addr, TIME_MIN)))
		min = config_setting_get_int(addr1);
	if (NULL != (addr1 = config_setting_get_member(addr, TIME_SEC)))
		sec = config_setting_get_int(addr1);

	if((mode == 0) && (hour >24)) {
		DBG("Name PPT Hour Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	if((mode != 0) && (hour > 12)) {
		DBG("Name PPT Hour Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	if(min>59) {
		DBG("Name PPT Min Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	if(sec>59) {
		DBG("Name PPT Sec Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	ptr->hour = hour;
	ptr->min = min;
	ptr->sec = sec;
	ptr ->mode = mode;
	DBG("Mode %d Hour %d Min %d sec %d",ptr->mode, ptr->hour,ptr->min, ptr->sec);
	return 0;
	
}

/*
 *  Fn     - read_config_file
 *  Brief  - read a parameter of any type from the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int read_config_file(config_setting_t *addr, void * in_ptr)
{
	TYPE *ptr;

	ptr = (TYPE *)in_ptr;
	DBG("\n The type is : ");
	switch (ptr->type)
	{
		case TEXT_STRING: 
			DBG("TXT_S");
			read_type_string(addr, in_ptr);
		break;
		case BOOLEAN:
			DBG("BOOLN");
			read_type_bool(addr, in_ptr);
		break;
		case INTEGER_VAR:
			DBG("INT_VAR");
			read_type_integer(addr, in_ptr);
		break;
		case FLOAT_VAR:
			DBG("FL_VAR");
			read_type_float(addr, in_ptr);
		break;
		case SET_OF_N:
			DBG("SET_N");
			read_type_setn(addr, in_ptr);
		break;
		case TIME_STORE:
			DBG("TIME_STORE");
			read_type_time(addr, in_ptr);
		break;
		default :
			DBG("NO MATCH");
			DBG("\nThe value is %d",ptr->type);
		break;
	}
	return 0;
}

/*
 *  Fn     - write_type_string
 *  Brief  - write a parameter of type string to the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int write_type_string(config_setting_t *addr, TXT_S *str_ptr)
{
	int len;

	len = strlen(str_ptr->value);
	if(len > str_ptr->limit) {
		DBG("Name PPT String Read ERROR: String lenth limit exceeded");
		return -1;
	}
	/* Write to file here */
		config_setting_set_string(addr,str_ptr->value);
	return 0;
}

/*
 *  Fn     - write_type_string
 *  Brief  - write a parameter of type integer to the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int write_type_integer(config_setting_t *addr, INT_VAR *ptr)
{
	 if ((ptr->min > ptr->value) || (ptr->max < ptr->value)) {
		DBG("Name PPT Integer Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	/* write to file here */
	config_setting_set_int(addr,ptr->value);

	return 0;
}

/*
 *  Fn     - write_type_string
 *  Brief  - write a parameter of type boolean to the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int write_type_bool(config_setting_t *addr, BOOLN *ptr)
{
	if ((ptr->value != _FALSE) && (ptr->value != _TRUE))	{
		DBG("Name PPT Bool Read ERROR: Not a boolean value");
		return -1;
	}
	/*Write to file here*/
	config_setting_set_int(addr,ptr->value);

	return 0;
}

/*
 *  Fn     - write_type_string
 *  Brief  - write a parameter of type float to the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int write_type_float(config_setting_t *addr, FL_VAR *ptr)
{
	if ((ptr->min > ptr->value) || (ptr->max < ptr->value)) {
		DBG("Name PPT Float Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	config_setting_set_float(addr,ptr->value);

	return 0;
}

/*
 *  Fn     - write_type_string
 *  Brief  - write a parameter of type setn to the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int write_type_setn(config_setting_t *addr, SET_N *ptr)
{
	
	if(ptr->current_index > ptr->max) {
		DBG("Name PPT Cuurent Index Read ERROR: Min/Max limit exceeded");
		return -1;
	}	
	/*write to file here*/
	config_setting_set_int(addr,ptr->current_index);

	return 0;
}

/*
 *  Fn     - write_type_string
 *  Brief  - write a parameter of type time to the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int write_type_time(config_setting_t *addr, TIME_VAR *ptr)
{
	config_setting_t *addr1;

	if((ptr->mode == 0) && (ptr->hour >24)) {
		DBG("Name PPT Hour Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	if((ptr->mode != 0) && (ptr->hour > 12)) {
		DBG("Name PPT Hour Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	if(ptr->min>59) {
		DBG("Name PPT Min Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	if(ptr->sec>59) {
		DBG("Name PPT Sec Read ERROR: Min/Max limit exceeded");
		return -1;
	}
	/* Write to file here*/
	if (NULL != (addr1 = config_setting_add(addr, TIME_MODE, CONFIG_TYPE_INT)))
		config_setting_set_int(addr1,ptr->mode);
	if (NULL != (addr1 = config_setting_add(addr, TIME_HOUR, CONFIG_TYPE_INT)))
		config_setting_set_int(addr1,ptr->hour);
	if (NULL != (addr1 = config_setting_add(addr, TIME_MIN, CONFIG_TYPE_INT)))
		config_setting_set_int(addr1,ptr->min);
	if (NULL != (addr1 = config_setting_add(addr, TIME_SEC, CONFIG_TYPE_INT)))
	config_setting_set_int(addr1,ptr->sec);

	return 0;
	
}

/*
 *  Fn     - write_config_file
 *  Brief  - write a parameter of any type to the config file
 *  Param  - level address, pointer to name property structure
 *  Return - 0 on sccess -1 failure
 */
int write_config_file(config_setting_t *addr, void * in_ptr)
{
	TYPE *ptr;

	ptr = (TYPE *)in_ptr;
	DBG("\n The type is : ");
	switch (ptr->type)
	{
		case TEXT_STRING: 
			DBG("TXT_S");
			write_type_string(addr, in_ptr);
		break;
		case BOOLEAN:
			DBG("BOOLN");
			write_type_bool(addr, in_ptr);
		break;
		case INTEGER_VAR:
			DBG("INT_VAR");
			write_type_integer(addr, in_ptr);
		break;
		case FLOAT_VAR:
			DBG("FL_VAR");
			write_type_float(addr, in_ptr);
		break;
		case SET_OF_N:
			DBG("SET_N");
			write_type_setn(addr, in_ptr);
		break;
		case TIME_STORE:
			DBG("TIME_STORE");
			write_type_time(addr, in_ptr);
		break;
		default :
			DBG("NO MATCH");
			DBG("\nThe value is %d",ptr->type);
		break;
	}
	return 0;
}

