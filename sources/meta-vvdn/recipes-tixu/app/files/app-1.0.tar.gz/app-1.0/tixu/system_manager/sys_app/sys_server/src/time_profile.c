#include <stdlib.h>
#include <string.h>
#include "time_profile.h"
#include <time.h>
#include <framework/types.h>
#include <group_scene_engine.h>
#include <actions_engine.h>
#include <sys_env_type.h>
#define START 0x1
#define STOP 0x02

#define TIME_PROFILE_DEBUG

#define FAILURE		0x01
#define SUCCESS		0x00
#ifdef TIME_PROFILE_DEBUG
#define DBG(fmt, args...)	fprintf(stderr, fmt, ##args)
#else
#define DBG(fmt, args...)
#endif

extern uint8_t sampleLightSeqNum;

const char weekdays[8][4] = {
	"SUN","MON","TUE","WED","THU","FRI","SAT","ALL"
};

int dayofweek(int d, int m, int y)
{
	int month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	int day[] = {0,1,2,3,4,5,6};
	int count;

	for (count = 1900; count < y; count++) {
		if (count % 4 == 0 && (count % 100 != 0 || count % 400 == 0)) {
			d += 366;
		} else {
			d += 365;
		}
	}
	for (count = 0; count < m - 1; count++){
		d += month[count];
	}
	return day[d%7];

}

int cmp_date4greater(UTCTimeStruct Date1,UTCTimeStruct Date2)
{
	if((Date1.year > Date2.year) ||
			((Date1.year == Date2.year) &&
			 ( Date1.month > Date2.month)) ||
			((Date1.year == Date2.year) &&
			 ( Date1.month == Date2.month)&&
			 ( Date1.day >= Date2.day))) {
		return SUCCESS;
	}
	return FAILURE;
}

int cmp_time4greater(UTCTimeStruct Time1,UTCTimeStruct Time2)
{
	if((Time1.hour > Time2.hour) ||
			((Time1.hour == Time2.hour) &&
			 (Time1.minutes > Time2.minutes ))) {
		return SUCCESS;
	}
	return FAILURE;
}

int cmp_time4equal(UTCTimeStruct Time1,UTCTimeStruct Time2)
{
	if((Time1.hour == Time2.hour) &&
			(Time1.minutes == Time2.minutes ) && (Time1.seconds == Time2.seconds)) {
		return SUCCESS;
	}
	return FAILURE;
}
int timer_check(UTCTimeStruct *Time)
{
	if(Time->seconds != NULL) {
		Time->seconds--;
	}
	else if((Time->seconds == NULL) && Time->minutes != NULL ) {
		Time->seconds = 59;
		Time->minutes--;
	} else if ( (Time->minutes == NULL) && (Time->hour != NULL)){
		Time->minutes =59;
		Time->hour--;
	} else {
		return SUCCESS;
	}
	return FAILURE;
}

void time_profile_process(void)
{
	int count ;
	SysInfo *pSysInfo = GetSysInfo();
	for(count = MIN_TIME_PROFILE; count <= MAX_TIME_PROFILE; count++) {
		if(pSysInfo->ProfileList[count-1].profile_status == PROFILE_NOT_EXIST ||
				pSysInfo->ProfileList[count-1].profile_status == PROFILE_CREATED ||
				pSysInfo->ProfileList[count-1].profile_status == PROFILE_IDLE ||
				pSysInfo->ProfileList[count-1].profile_status == PROFILE_INACTIVE ||
				pSysInfo->ProfileList[count-1].profile_status == PROFILE_EXPIRED) {
			continue;
		}

		switch(pSysInfo->ProfileList[count-1].time_action) {
			case PROFILE_ACTION_WEEK:
				process_week(count-1);
				break;
			case PROFILE_ACTION_TIMER:
				process_timer(count-1);
				break;
			default:
				break;
		}
	}

}

void process_timer(uint8_t profile_id)
{
	SysInfo *pSysInfo = GetSysInfo();
	switch(pSysInfo->ProfileList[profile_id].profile_status)
	{
		case PROFILE_ACTIVE:
			if ( timer_check( &pSysInfo->ProfileList[profile_id].time)== SUCCESS) {
				process_action(profile_id,START);
				memset(&pSysInfo->ProfileList[profile_id],0,sizeof(TimeProfile_t));
			}
	}
}

void process_week(uint8_t profile_id)
{
	uint8_t weekday;
	UTCTimeStruct curTime;
	SysInfo *pSysInfo = GetSysInfo();
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	curTime.hour   = tm.tm_hour;
	curTime.minutes = tm.tm_min;
	curTime.seconds   = tm.tm_sec;

	weekday = (uint8_t)dayofweek(tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900);

	if(1<<weekday & pSysInfo->ProfileList[profile_id].week.week_mask) {

		switch(pSysInfo->ProfileList[profile_id].profile_status)
		{
			case PROFILE_ACTIVE:

				if(SUCCESS == cmp_time4equal(curTime,pSysInfo->ProfileList[profile_id].time)) {
					process_action(profile_id,START);
					if(REPEAT_DISABLE & pSysInfo->ProfileList[profile_id].week.repeat) {
						pSysInfo->ProfileList[profile_id].week.week_mask &= ~(1<<weekday);
					}
					if(pSysInfo->ProfileList[profile_id].week.week_mask) {
						pSysInfo->ProfileList[profile_id].profile_status = PROFILE_ACTIVE;
					}else {
						pSysInfo->ProfileList[profile_id].profile_status = PROFILE_EXPIRED;
						memset(&pSysInfo->ProfileList[profile_id],0,sizeof(TimeProfile_t));

					}
				}
		}

	}

}

void process_action(uint8_t profile_id,uint8_t action)
{
	int action_id;
	uint8_t state;//,hue_val,sat_val,level_val;
	SysInfo *pSysInfo = GetSysInfo();
	uint16_t group_mask = pSysInfo->ProfileList[profile_id].group_mask;
	int index ;
	int ep_index, i, l;
	uint64_t ieee_addr;
	zb_addr_t destination_addr;
	action_id = pSysInfo->ProfileList[profile_id].control_action_mask;

	if(action & START) {
		state = pSysInfo->ProfileList[profile_id].start_state;
	}

	DBG("process_action action_id %d state :%d\n", action_id, state);
	for(index = 0; index <= MAX_GROUP_ID; index++) {
		if  ( 1<< index & group_mask) {
#ifdef SMARTPLUG
			if (index < MAX_GROUP_ID) {
				for (l = 0; l < MAX_GROUP_MEM; l++) {
					if (ieee_addr = pSysInfo->group_info[index].nodemem[l]) {
						for (i = 0; i < ds_devices_total; i++) { /*Finding the location(index) of node in ds_device_table structure*/
							if (ieee_addr == ds_device_table[i].ieee_addr) 
								break;
						}
						ep_index = ds_device_table[i].control_endpoint_index;
						destination_addr.ieee_addr = ds_device_table[i].ieee_addr;
						destination_addr.endpoint = ds_device_table[i].ep_list[ep_index].endpoint_id;
					}
				}
			} else {
				destination_addr.ieee_addr = 0;
				destination_addr.groupaddr = 0xFFFFFFFF;
			}
			if(action_id & (PROFILE_CONTROL_STATE | PROFILE_CONTROL_COLOR)) {
				while (si_is_waiting_for_confirmation());
				act_set_onoff( &destination_addr,state );
				pSysInfo->group_info[index].ON_OFF_STATE = state;
			}
#else
			destination_addr.ieee_addr = 0;
			if (index < MAX_GROUP_ID)
				destination_addr.groupaddr = index;
			else
				destination_addr.groupaddr = 0xFFFFFFFF;

			if(action_id & (PROFILE_CONTROL_STATE | PROFILE_CONTROL_COLOR)) {
				while (si_is_waiting_for_confirmation());
				act_set_onoff( &destination_addr,state );
				pSysInfo->group_info[index].ON_OFF_STATE = state;
			}
#endif

		}
	}
}


