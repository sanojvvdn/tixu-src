/*==========================================================================
 * @file	:cgi.c
 * @path	:sys_app/utils/firmware_upgrade_utils/src
 * @desc	:Firmware upgrade image validity checking and writing images into
 * corresponding flash location.
 * Author	:
 * The code contained herein is licensed under the GNU General Public
 * License.
 * You may obtain a copy of the GNU General Public License Version 2 or
 * later at the following locations:
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 *==========================================================================*/

#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<image.h>
#include<sys/stat.h>

#define UPLOAD_BLOCK_SIZE  512
#define FILE_NAME_SIZE  80

static int gLastI = -1, gLastRead;

/*
 * @func    :Reverse
 * @brief   :This function is called to reverse the file name
 * @arg :*pStr
 * */

void Reverse(char *pStr)
{
	int i, j;
	char temp;
	for (i = 0, j = strlen(pStr) - 1; i < j; i++, j--) {
		temp = pStr[i];
		pStr[i] = pStr[j];
		pStr[j] = temp;
	}
}

/*
 * @func    :TakeFileName
 * @brief	:This function is called to extract the file name.
 * @arg		:pbuf, nBufSize, pFileName
 * */

void TakeFileName(char *pbuf, int nBufSize, char *pFileName)
{
	int i, count = 0;
	for (i = 0; i < nBufSize; i++) {
		if (pbuf[i] != '"')
			continue;
		gLastI = i;
		while (--i >= 0) {
			if (pbuf[i] == '/' || pbuf[i] == '\\')
				break;
			pFileName[count++] = pbuf[i];
		}
		break;
	}
	pFileName[count] = '\0';
	Reverse(pFileName);
	return ;
}

/*
 * @func    :GetFileName
 * @brief	:This function is called to get the image name.
 * @arg		:fd, pBuf, nBufSize
 * @return	:image name
 * */

char *GetFileName(int fd, char *pBuf, int nBufSize)
{
	static char strFileName[FILE_NAME_SIZE + 1];
	const char target[] = "filename=\"";
	int nReadBytes = 0, count = 0, i, tempI = gLastI;
	while ((nReadBytes = read(fd, pBuf, nBufSize)) > 0) {
		for (i = 0; i < nBufSize; i++) {
			if (count == strlen(target)) {
				gLastI = i;
				TakeFileName(&pBuf[i], nReadBytes - i, strFileName);
				if (strFileName[0] == '\0') {
					count = 0;
					gLastI = tempI;
				} else {
					gLastRead = nReadBytes;
					return strFileName;
				}
			} else if (pBuf[i] == target[count])
				count++;
			else
				count = 0;
		}
	}
	return NULL;
}

/*
 * @func    :SkipHeader
 * @brief	:This function is called to skip header from the image.
 * @arg		:fd, pBuf, nBufSize
 * @return	:image name
 * */

int SkipHeader(int fd, char *pBuf, int nBufSize)
{
	int i, count = 0;
	const char target[] = "\r\n\r\n";
	if (gLastRead > 0) {
		i = (gLastI > 0) ? gLastI : 0;
		do {
			for (; i < gLastRead; i++) {
				if (count == strlen(target))
					return i;
				else if (pBuf[i] == target[count])
					count++;
				else
					count = 0;
			}
			i = 0;
		} while ((gLastRead = read(fd, pBuf, nBufSize)) > 0);
	} else {
		while ((gLastRead = read(fd, pBuf, nBufSize)) > 0) {
			for (i = 0; i < gLastRead; i++)
				if (count == strlen(target))
					return i;
				else if (pBuf[i] == target[count])
					count++;
				else
					count = 0;
		}
	}
	return -1;
}

int main(int argc, char **argv)
{
	char buffer[512], *pFileName,file_name_path[80], cmd1[256], cmd[64];
	FILE *fd, *fd_sec, *fd_primary,*fd_secondary;
	char *buf;
	unsigned int size;
	int len, pos, readLen,chunks, remainder ,rd, i;
	struct stat file_buf,st;
	uint8_t *pData;

	buf = malloc(UPLOAD_BLOCK_SIZE);
	fstat(STDIN_FILENO, &st);

	pFileName = GetFileName(STDIN_FILENO, buffer, sizeof(buffer));
	gLastI = SkipHeader(STDIN_FILENO, buffer, sizeof(buffer));

	if (stat(OTA_FOLDER, &file_buf) != 0) {
		sprintf(cmd, "mkdir -p %s \n", OTA_FOLDER);
		system(cmd);
	} else {
		sprintf(cmd1, "rm -rf %s/* \n", OTA_FOLDER);
		system(cmd1);
	}

	if (stat(OTA_PRIMARY_IMAGE, &file_buf) == 0 || stat(OTA_SECONDARY_IMAGE,&file_buf)==0) {
		printf("Removing old fw from config partition \n");
		system("rm /mnt/config/OTA_FW*");
	}

	sprintf(file_name_path, "/tmp/ota/%s", pFileName);
	fd = fopen(OTA_DOWNLOAD_IMAGE, "a+");
	if (fd < 0)
		printf("FAILED:UNABLE TO OPEN FILE\n");
	for (i = gLastI; i < sizeof(buffer); i++)
		fprintf(fd, "%c", buffer[i]);

	int data_left, data_done;
	data_done = 512 - gLastI;
	data_left = size - data_done + 64;
	chunks = data_left/UPLOAD_BLOCK_SIZE;
	remainder = data_left%UPLOAD_BLOCK_SIZE;
	do {
		if (chunks == 1) {
			rd = read(STDIN_FILENO, buf, 1);
			fwrite(buf, 1, rd, fd);
			data_left = data_left - rd;
		} else {
			rd = read(STDIN_FILENO, buf, UPLOAD_BLOCK_SIZE);
			fwrite(buf, 1, rd, fd);
			chunks--;
			data_left = data_left - rd;
		}

		if (rd == 0) {
			sleep(10);
			rd = read(STDIN_FILENO, buf, UPLOAD_BLOCK_SIZE);
		}

	} while (rd != 0 && data_left);


	fseek(fd, 0L, SEEK_END);
	pos = ftell(fd);
    fseek(fd, 0L, SEEK_SET);

    //Also allocate space for firmware pData
    pData = malloc(pos);


    // Read the image data
    readLen = (int) fread(pData, 1, pos, fd);

    if (readLen == pos) {
      // Parse the header
      ParseOTAHeader(&header, pData);
	  if (header.magicNumber == OTA_HDR_MAGIC_NUMBER)
	  {
		  printf("OTA header magic number matcheed\n");
	  }
	  else{
		  printf("MAGIC NUM not matched\n");
		  return;
	  }
	}
	else
		printf("Could not read image file\n");

	if(pos > header.imageSize)
	{
		rewind(fd);
		fd_primary = fopen("/mnt/config/OTA_FW_PRI", "w");
		for(i= 1; i <= header.imageSize;i++)
		{
			rd = fgetc(fd);
			fputc(rd, fd_primary);
		}

		fclose(fd_primary);
		fd_secondary = fopen("/mnt/config/OTA_FW_SEC", "w");
		for(i= 1; i <= header.imageSize; i++)
		{
			rd = fgetc(fd);
			fputc(rd, fd_secondary);
		}

		fclose(fd_secondary);
	}
	free(buf);
	fclose(fd);

	printf("OTA FIRMWARE FILE %s UPLOADED\n", pFileName);
	return 0;
}
/******************************************************************************
 * @fn      OTA_ParseHeader
 *
 * @brief   Reads the OTA header from the input buffer.
 *
 * @param   pHdr - pointer to the header information
 * @param   pBuf - pointer to the input buffer
 *
 * @return  new buffer pointer
 */
void ParseOTAHeader(OTA_ImageHeader_t *pHdr, uint8_t *pBuf)
{
  uint8_t i;

  // Get the Magic Number
  pHdr->magicNumber = BUILD_UINT32(pBuf[0], pBuf[1], pBuf[2], pBuf[3]);
  pBuf += 4;

  // Get the Header Version
  pHdr->headerVersion = BUILD_UINT16(pBuf[0], pBuf[1]);
  pBuf += 2;

  // Get the Header Length
  pHdr->headerLength = BUILD_UINT16(pBuf[0], pBuf[1]);
  pBuf += 2;

  // Get the Field Control
  pHdr->fieldControl = BUILD_UINT16(pBuf[0], pBuf[1]);
  pBuf += 2;

  // Get the Manufacturer ID
  pHdr->fileId.manufacturer = BUILD_UINT16(pBuf[0], pBuf[1]);
  pBuf += 2;

  // Get the Image Type
  pHdr->fileId.type = BUILD_UINT16(pBuf[0], pBuf[1]);
  pBuf += 2;

  // Get the File Version
  pHdr->fileId.version = BUILD_UINT32(pBuf[0], pBuf[1], pBuf[2], pBuf[3]);
  pBuf += 4;

  // Get the Stack Version
  pHdr->stackVersion = BUILD_UINT16(pBuf[0], pBuf[1]);
  pBuf += 2;

  // Get the Header string
  for (i=0; i<OTA_HEADER_STR_LEN; i++)
  {
    pHdr->headerString[i] = *pBuf++;
  }

  // Get the Image Size
  pHdr->imageSize = BUILD_UINT32(pBuf[0], pBuf[1], pBuf[2], pBuf[3]);
  pBuf += 4;

  // Get the Security Credential Version
  if (pHdr->fieldControl & OTA_FC_SCV_PRESENT)
  {
    pHdr->secCredentialVer = *pBuf++;
  }

  // Get the Upgrade File Destination
  if (pHdr->fieldControl & OTA_FC_DSF_PRESENT)
  {
    for (i=0; i<Z_EXTADDR_LEN; i++)
    {
      pHdr->destIEEE[i] = *pBuf++;
    }
  }

  // Get the Min and Max Hardware Versions
  if (pHdr->fieldControl & OTA_FC_HWV_PRESENT)
  {
    pHdr->minHwVer = BUILD_UINT16(pBuf[0], pBuf[1]);
    pBuf += 2;
    pHdr->maxHwVer = BUILD_UINT16(pBuf[0], pBuf[1]);
    pBuf += 2;
  }

 // return pBuf;
}
