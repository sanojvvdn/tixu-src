
/** 
 * NET_CONFIG FUNCTIONS
 **/
void *NetworkMngThread(void *arg);
int wifi_config();
int wifi_security_check_client();
