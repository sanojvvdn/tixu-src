/* ===========================================================================
 * @file name_prpoperty.h
 *
 * @path sys_app/sys_server/inc
 *
 * @desc File manager libconfig name property interface defnitions.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/
#ifndef NAME_PROPERTY_H_
#define NAME_PROPERTY_H_

#include <libconfig.h>

enum {
	TEXT_STRING = 0,
	BOOLEAN,
	INTEGER_VAR,
	FLOAT_VAR,
	SET_OF_N,
	TIME_STORE
};

enum {
	HRS_24_12 = 0,
	AM,
	PM
};

enum {
	_TRUE = 1,
	_FALSE = 0
};

typedef struct {
	int type;
}TYPE;

typedef struct {
	int type;
	int limit;
	char value[];
}TXT_S;

typedef struct {
	int type;
	int value;
}BOOLN;

typedef struct {
	int type;
	int min;
	int max;
	int value;
}INT_VAR;

typedef struct {
	int type;
	float min;
	float max;
	float value;
}FL_VAR;

typedef struct {
	int value;
	char symbol[16];
}SET;

typedef struct {
	int type;
	int max;
	int current_index;
	SET set[];
}SET_N;

typedef struct {
	int type;
	int mode;
	int hour;
	int min;
	int sec;
}TIME_VAR;

int read_config_file(config_setting_t *addr, void * in_ptr);
int write_config_file(config_setting_t *addr, void * in_ptr);
#endif
