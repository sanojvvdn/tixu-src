/* ===========================================================================
 * @file sysctrl.h
 *
 * @path sys_app/interface/inc
 *
 * @desc Send commands to system server.This is the communication interface of
 *	 system server.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/
/**
 * @page SYSCTRL_HOW How to use system command API?

* 1. Add new command to list if needed.\n
* 2. Now you can use any system command functions as you want.\n
* @section SYSCTRL_HOW_EX Example

#include <sysctrl.h>
int main()
{
	int value = 0;
	if(ControlSystemData( // system command here, &value, sizeof(value)) < 0){
		return -1;
	}
	return 0;
}
*/

#ifndef __SYS_CONTROL_H__
#define __SYS_CONTROL_H__

/* 
   Supported methods
 */
#define GET 0
#define POST 1
#define PUT 6
#define DELETE 8

#define MAX_JSON_LENGTH 6000
/*
Structure used to communicate REST API's to system server
*/
typedef struct __COMMAND_ARGUMENT {
    char name[100]; //API in hashtable
    char user[100]; //user called API
    char value[MAX_JSON_LENGTH]; //Value's of API 
    int method; //http method
    int target1; 
	int target2;
	int flags;
	unsigned int ip_pushaddr;
} COMMAND_ARGUMENT;

/* **
 * @brief Command list.
 */
typedef enum
{
	SYS_CMD_TEST = 0,
	WIFI_MODE_CHANGE,
	WIFI_CLIENT_MODE_PARAMS,
	WIFI_AP_MODE_PARAMS,
	SYS_CMD_BLE_UUID,
	SYS_CMD_BLE_ADV_CHANNEL,
	SYS_CMD_NODE,
	SYS_CMD_NODE_STATE,
	SYS_CMD_NODE_TYPE,
	SYS_CMD_NODE_NAME,
	SYS_CMD_NODE_MODELID,
	SYS_CMD_NODE_SWVERSION,
	SYS_CMD_NODE_NEW,
	SYS_CMD_GATEWAY,
	SYS_CMD_GROUP,
	SYS_CMD_GROUP_STATE,
	SYS_CMD_GROUP_NODE,
	SYS_CMD_GROUP_NAME,
	SYS_CMD_GROUP_DELETE_NODE,
	SYS_CMD_REGISTER_FOR_PUSH,
	SYS_CMD_UNREGISTER_FROM_PUSH,
	SYS_CMD_DHCP_ENABLE,
	SYS_CMD_SET_STATIC_PARAMETERS,
	SYS_CMD_TIME_PROFILE,
	SYS_CMD_PROFILE_STATUS,
	SYS_CMD_PROFILE_GROUP,
	SYS_CMD_TIMER,
	SYS_CMD_TIMER_SET,
	SYS_CMD_PROFILE_SET,
	SYS_CMD_PROFILE_GET,
	SYS_CMD_SET_TIME,
	SYS_CMD_SENSOR,
	SYS_CMD_FLSENSOR,
	SYS_CMD_GET_POWER,
	SYS_CMD_GET_MONTH_POWER,
	SYS_CMD_TIMEZONE,
	SYS_CMD_OTA
} SYSTEM_CONTROL;

int ControlSystemData(unsigned int field, void *data, unsigned int len); ///<  Protype definition.

#endif   /* __SYS_CONTROL_H__ */

