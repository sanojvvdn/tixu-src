/* ===========================================================================
 * @file ddr_flags.h
 *
 * @path $(IPNCPATH)\SPRS\DVEN\include
 *
 * @desc This file contains the defnitions and declarions for DDR Flag
 * implementation.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ========================================================================== */

#ifndef _DDR_FLAGS_H_
#define _DDR_FLAGS_H_

#define DDR_FLAG_LOCATION  0x88000000
#define GPIO0_LOCATION		0x48032138

#define OSD		8
#define AUDIO		7
#define AUTO_IRIS	6
#define ALARM		5
#define PTZ		4
#define SD		3
#define RTC		2
#define USB		1
#define POE		0

#define POR_MAGIC_NUMBER_1	0xAA
#define POR_MAGIC_NUMBER_2	0xBB
#define POR_MAGIC_NUMBER_3	0xCC

enum setClear {
	SET_VALUE,
	CLEAR_VALUE
};

enum rebootReason {
	POWER_ON,
	BOOT_FAIL,
	WDT_REBOOT,
	SOFTWARE_UPGRADE,
	SOFTWARE_REBOOT
};

typedef struct SysDdrFlags {
	unsigned int system_flag;		/*0x00 */
	unsigned int switch_status;		/*0x04 */
	unsigned int version;			/*0x08 */
	unsigned int revision;			/*0x0C */
	unsigned int wdr_count;			/*0x10 */
	unsigned int boot_fail_count;		/*0x14 */
	unsigned int reboot_reason;		/*0x18 */
	unsigned int saved_reboot_reason;	/*0x1C */
	unsigned char ubl_version[20];		/*0x20 */
	unsigned char uboot_version[20];	/*0x34 */
	int reboot_magic_no_1;			/*0x48 */
	int reboot_magic_no_2;			/*0x4C */
	int reboot_magic_no_3;			/*0x50 */
} sysDdrFlags;

typedef struct Gpioflag {
	unsigned int datain;
} gpioflag;

void DDR_FLAGS_setRestoreFlag(int value);
int DDR_FLAGS_getRestoreFlag(void);
int DDR_FLAGS_setClrSystemFlag(char set_clr, unsigned int position);
int DDR_FLAGS_getSystemFlag(void);
void DDR_FLAGS_setVersion(void);
int DDR_FLAGS_getVersion(void);
void DDR_FLAGS_setRevision(void);
int DDR_FLAGS_getRevision(void);
int DDR_FLAGS_getWdrCount(void);
int DDR_FLAGS_getRebootReason(void);
void DDR_FLAGS_backupPinStates(void);
void DDR_FLAGS_restorePinStates(void);
int DDR_FLAGS_getBootFailCount(void);
void DDR_FLAGS_setBootFailCount(int count);
void DDR_FLAGS_setRebootReason(int value);
void DDR_FLAGS_setWdrCount(int count);
void DDR_FLAGS_initSystemFlag(void);
void DDR_FLAGS_saveRebootReason(int value);
void DDR_FLAGS_setUblVersion(void);
int DDR_FLAGS_check_por(void);

#endif				/*_DDR_FLAGS_H_*/
