/* ===========================================================================
 * @file File_Msg_Def.h
 *
 * @path sys_app/interface/inc
 *
 * @desc Definition of the message ID to communicate with file manager the ID 
 * could be used by one process only MSG_TYPE_MSG10 is the maximum.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/


#ifndef _FILE_MSG_DEF_H_
#define _FILE_MSG_DEF_H_
/* MSG_TYPE_MSG1 is reserved for system server */

#define FILE_SYS_MSG		MSG_TYPE_MSG2 /* message ID used in System Server to communicate with file manager.*/
#define FILE_LTY_MSG		MSG_TYPE_MSG3 /* message ID used in Lighttp to communicate with file manager.*/
#define FILE_UPNP_MSG		MSG_TYPE_MSG4 /* message ID used in Upnp to communicate with file manager.*/
#define SENSOR_MSG_TYPE        MSG_TYPE_MSG7 /* message ID used in Zigbee sensor to communicate with system server*/
#endif

