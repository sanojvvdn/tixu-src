/* ===========================================================================
 * @file file_mng.h
 *
 * @path sys_app/sys_server/inc
 *
 * @desc file manger api functions.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/
 
#ifndef __FILE_MNG_H__
#define __FILE_MNG_H__

#include <sys_env_type.h>
int FileMngInit(void *ShareMem);
int FileMngExit();
int ReadGlobal(void *Buffer);
int WriteGlobal(void *Buffer);
int FileMngReset(void *ShareMem);
int IsFileThreadQuit();
void *FileMngThread(void *arg);
#endif   /* __FILE_MNG_H__ */
