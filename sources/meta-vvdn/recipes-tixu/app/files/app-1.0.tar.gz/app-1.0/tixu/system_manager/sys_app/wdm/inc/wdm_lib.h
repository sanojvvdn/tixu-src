/* ===========================================================================
 * @file wdm_lib.h
 *
 * @path $(IPNCPATH)\wdm\inc
 *
 * @desc This file has the defnitions and declration for WDM and WD library.
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/
#ifdef __cplusplus
extern "C" {
#endif
#ifndef _WDM_LIB_H_
#define _WDM_LIB_H_
/*Message Types*/
#define REGISTER	1
#define DEREGISTER	2
#define ALIVE		3
#define ALIVE_Q     4
/*Action*/
#define REBOOT		1
#define WARN		2
#define WARN_REBOOT	3
/*WDM Parameters*/
#define WDM_NAME		"wdm"
#define TABLE_SIZE		10
#define TASK_NAME_SIZE		10
#define WDM_PRINT_TIME		10		/*in seconds*/
#define WDM_TICK_TIME		100		/*in milliseconds(multiple of 10)*/
#define SIGNAL_SEND_TIME	10		/*in seconds*/
#define WDT_DRIVER_PATH	/dev/watchdog
#define WDT_TIMEOUT         10
#define MAX_WARNINGS        3
/*Message Queue Parameters*/
#define MSGSZ		128
#define WDM_MSGQ_KEY	1234
enum {
		WDM_MSG_TYPE_START = 0,
		WDM_MSG_TYPE_MSG1,	/*< Message type 1.
							  Always reserved for wdm manager.*/
		WDM_MSG_TYPE_MSG2,	/*< Message type 2.*/
		WDM_MSG_TYPE_MSG3,	/*< Message type 3.*/
		WDM_MSG_TYPE_MSG4,	/*< Message type 4.*/
		WDM_MSG_TYPE_MSG5,	/*< Message type 5.*/
		WDM_MSG_TYPE_MSG6,	/*< Message type 6.*/
		WDM_MSG_TYPE_END
	};
#define WDM_SYS_MSG		WDM_MSG_TYPE_MSG2
#define WDM_RTSP_MSG	WDM_MSG_TYPE_MSG3
#define WDM_LGHTP_MSG	WDM_MSG_TYPE_MSG4
#define WDM_RESETD_MSG	WDM_MSG_TYPE_MSG5

//*    Tasks in TIXU  */
#define LGHTP_SERVER    "Lighttpd"
#define SYSTEM_SERVER   "SYS_SERVER"
/*
 * Declare the message structure.
 */

typedef struct wdmmsgbuf {
	long mtype;
int cmd;
int tsk_msg_type;
char mtext[MSGSZ];
} wdm_message_buf;

/*
 * API for WDM library
 */
int checkWdmReady(void);
int wdmMessage(int req_type, char *message, int timeout, int tsk_msg_type);


#endif	/*_WDM_LIB_H_*/
#ifdef __cplusplus
}
#endif
