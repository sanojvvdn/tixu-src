/*==============================================================
 * @file	:fw_upgrade.c
 * @path	:sys_app/utils/ota_upgrade/src
 * @desc	:The web page loaded upon calling the api for ota firmware upgradation.
 * Author	:
 *  The code contained herein is licensed under the GNU General Public
 * License.You may obtain a copy of the GNU General Public License Version 2 or
 * later at the following locations:
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 *==========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

const char update_html_head[] =
"HTTP/1.1 200 OK\r\nContent-type: text/html\r\nPragma: no-cache\r\n"
"Cache-Control: no-store\r\n\r\n"
"<HTML><HEAD><TITLE>OTA Firmware Update</TITLE>\n"
"<script src='/js/jquery/jquery.min.js'></script>\n"
"<script>\n"
"$(document).ready(function(){\n"
"$('#fw_div').show();\n"
"$('#process').hide();\n"
"});\n"
"function  validate(){\n"
"var file=document.getElementById('file_fw').value;\n"
"if (file == '') {\n"
"alert('No File Selected.Please select firmware and upgrade again!!');\n"
"return false;\n"
" }\n"
"else { \n"
"document.getElementById('fw_form').submit();\n"
"$('#fw_div').hide();\n"
"$('#process').show();\n"
"}\n"
"}\n"
"</script></HEAD>\n"
"<BODY>\n"
"<div id='process'>\n"
"<h2 align='center'> Upgrading ota fw.... Please wait...</h2>\n"
"<h2 align='center'>[Please do not reboot the system]</h2>\n"
"</div>\n"
"<div id='fw_div'>\n"
"<form method=\"post\" id=\"fw_form\" enctype=\"multipart/form-data\" "
"   action=\"ota.cgi\">\n"
"<input type=\"file\"  id=\"file_fw\" name=\"binary1\"> (Select A Local File)\n"
"<input type=\"button\" onclick=\"validate()\"  value=\"UPLOAD FILE\" >\n"
"<p>\n"
"</form>\n"
"</div>\n"
"</BODY></HTML>\n";

int main(void)
{
	write(STDOUT_FILENO, update_html_head, sizeof(update_html_head));
	return 0;
}
