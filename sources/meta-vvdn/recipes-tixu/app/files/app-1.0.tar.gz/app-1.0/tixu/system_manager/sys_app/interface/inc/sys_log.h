/* ===========================================================================
 * @path $(PUBLIC_INCLUDE_DIR)
 *
 * @desc
 * .
 * Copyright (c) VVDN Technologies Pvt Ltd.  2013
 *
 *  The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html

 *
 * =========================================================================== */
/*
 * @file sys_log.h
 * @brief  API to syslog entry handling
 */
#ifndef __SYS_LOG_H__
#define __SYS_LOG_H__

#define MAX_SUBSTRING_LENGTH 20
#define LINES_PER_PAGE 15
#define MAX_LOG_ENTRY_LENGTH 200
#define DATE_LENGTH 22      // with year
#define DATE_LIMIT 15       //without Year
#define PROGRAM_NAME_LENGTH 20
#define FACILITY_LENGTH 20
#define MAX_LOG_MSG_LENGTH 100

#define SYSLOG_FILE "/tmp"

/**
 * This is the communication interface of syslog entry handling
 */
char log_msg[256];

typedef struct syslog_entry {
    char date[DATE_LENGTH];
    char program_name[PROGRAM_NAME_LENGTH];
    char facility[FACILITY_LENGTH];
    char message[MAX_LOG_MSG_LENGTH];
    int id;
    int line_number;
}SYSLOG_ENTRY;

typedef struct count {
    int category;     // Facility category selected
    int count;      // number of results found
    char substring[MAX_SUBSTRING_LENGTH];   // substring to be searched
}SYSLOG_ENTRY_COUNT;

typedef struct page {
    int page_number;    // Requested page
    int total_count;
    int category;
    char substring[MAX_SUBSTRING_LENGTH];   // substring to be searched
    SYSLOG_ENTRY entry[LINES_PER_PAGE];     // array to store the log messages on a page
}SYSLOG_PAGE;

#endif
