	void *ZigbeeThread(void);
	void register_segmentation_fault_handler(void);
	void segmentation_fault_handler(int signum, siginfo_t *info, void *context);
	void unregister_segmentation_fault_handler(void);
