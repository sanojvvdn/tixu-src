/*
 * (C) Copyright 2000-2005
 * Wolfgang Denk, DENX Software Engineering, wd@denx.de.
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 *
 ********************************************************************
 * NOTE: This header file defines an interface to U-Boot. Including
 * this (unmodified) header file in another file is considered normal
 * use of U-Boot, and does *not* fall under the heading of "derived
 * work".
 ********************************************************************
 */

#ifndef __IMAGE_H__
#define __IMAGE_H__

#include<stdint.h>

#define OTA_FOLDER "/tmp/ota"
#define OTA_HEADER_STR_LEN                  32
#define OTA_DOWNLOAD_IMAGE               "/tmp/ota/ota_firmware"
#define OTA_CFG_FILE		"/home/root/zigbee/servers/sample_app_ota.cfg"
#define OTA_PRIMARY_IMAGE		"/mnt/config/OTA_FW_PRI"
#define	OTA_SECONDARY_IMAGE			"/mnt/config/OTA_FW_SEC"
#define OTA_HDR_MAGIC_NUMBER                0x0BEEF11E
#define OTA_FC_SCV_PRESENT                  (0x1 << 0)
#define OTA_FC_DSF_PRESENT                  (0x1 << 1)
#define OTA_FC_HWV_PRESENT                  (0x1 << 2)
#define Z_EXTADDR_LEN   8

#define BUILD_UINT32(Byte0, Byte1, Byte2, Byte3) \
	((uint32_t)((uint32_t)((Byte0) & 0x00FF) \
		+ ((uint32_t)((Byte1) & 0x00FF) << 8) \
		+ ((uint32_t)((Byte2) & 0x00FF) << 16) \
		+ ((uint32_t)((Byte3) & 0x00FF) << 24)))

#define BUILD_UINT16(loByte, hiByte) \
	((uint16_t)(((loByte) & 0x00FF) + (((hiByte) & 0x00FF) << 8)))

#define HI_UINT16(a) (((a) >> 8) & 0xFF)
#define LO_UINT16(a) ((a) & 0xFF)

#define BUILD_UINT8(hiByte, loByte) \
	((uint8_t)(((loByte) & 0x0F) + (((hiByte) & 0x0F) << 4)))

#define HI_UINT8(a) (((a) >> 4) & 0x0F)
#define LO_UINT8(a) ((a) & 0x0F)

typedef struct{
  uint16_t manufacturer;
  uint16_t type;
  uint32_t version;
} zclOTA_FileID_t;

typedef struct
{
	uint32_t magicNumber;
	uint16_t headerVersion;
	uint16_t headerLength;
	uint16_t fieldControl;
	zclOTA_FileID_t fileId;
	uint16_t stackVersion;
	uint8_t headerString[OTA_HEADER_STR_LEN];
	uint32_t imageSize;
	uint8_t secCredentialVer;
	uint8_t destIEEE[8];
	uint16_t minHwVer;
	uint16_t maxHwVer;
} OTA_ImageHeader_t;

OTA_ImageHeader_t header;

#endif	/* __IMAGE_H__ */
