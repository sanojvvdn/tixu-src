/* ===========================================================================
 * @file file_msg_drv.h
 *
 * @path $sys_app/sys_server/src
 *
 * @desc This file contains the semaphore API's 
 *
 * AUTHOR: sarin.ms@vvdntech.com
 *
 * The code contained herein is licensed under the GNU General Public  License.
 * You may obtain a copy of the GNU General Public License Version 2 or later
 * at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 * ==========================================================================*/

#ifndef _SEM_UTIL_H_
#define _SEM_UTIL_H_

int Sem_Creat();
int Sem_unlock();
int Sem_lock();
int Sem_kill();


#endif
